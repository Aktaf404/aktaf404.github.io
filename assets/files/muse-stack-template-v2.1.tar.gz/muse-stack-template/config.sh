# =====================================================================
# config.sh — variabel instalasi muse-stack-template
# Edit nilai di sini SEBELUM menjalankan install.sh.
# Untuk override tanpa mengubah template, buat file config.local.sh
# di direktori yang sama (otomatis di-load bila ada).
# =====================================================================

# --- 9router ---------------------------------------------------------
NINEROUTER_VERSION="0.5.95"          # versi 9router yang sudah teruji
NINEROUTER_PORT="20128"              # port dashboard/API 9router

# --- muse-bridge (shim OpenAI-compatible -> Muse worker) -------------
SHIM_PORT="20501"                    # port shim lokal
BRIDGE_PREFIX="kamu"                 # prefix model, mis. kamu/agent
BRIDGE_NAME="Muse Bridge"            # nama provider node di 9router

# --- provider gratis (Pollinations, tanpa API key) -------------------
POLL_PREFIX="pllns"
POLL_NAME="Pollinations"
# Base URL node Pollinations di 9router. Bila USE_CAVEMAN=1 (default),
# node didaftarkan lewat caveman proxy lokal (lihat bawah) — catat di sini
# sebagai konfigurasi, BUKAN hardcode di skrip. Untuk instalasi yang sudah
# terdaftar dengan baseUrl lama: ubah manual di dashboard 9router, atau
# hapus node lalu jalankan ulang register-providers.py.
POLL_BASE_URL="https://text.pollinations.ai/openai"
POLL_MODELS="gpt-oss,openai-fast"    # koma-dipisah; didaftarkan sebagai <prefix>/<model>

# --- caveman: token-saver proxy (upstream optimizer 9router) -----------
INSTALL_CAVEMAN="1"                  # 0 = lewati, 1 = pasang caveman
CAVEMAN_NPM="@caveman-ai/cli@2.0.0"  # paket npm CLI (sumber biner standalone)
CAVEMAN_PORT="8788"                  # port listen caveman-proxy
USE_CAVEMAN="1"                      # 1 = POLL_BASE_URL lewat caveman
                                     #     (http://127.0.0.1:8788/v1);
                                     # 0 = langsung ke text.pollinations.ai.
                                     # Node kamu/agent SENGAJA tidak lewat
                                     # caveman (jangan diubah).

# --- headroom: Token Saver proxy (context optimizer 9router) -----------
INSTALL_HEADROOM="1"                 # 0 = lewati, 1 = pasang headroom
HEADROOM_VERSION="0.39.1"            # versi headroom-ai[proxy] yang teruji
HEADROOM_PORT="8787"                 # port listen headroom proxy
# Catatan: setelah install, aktifkan MANUAL di dashboard 9router:
# Endpoint -> Token Saver -> Headroom -> http://localhost:8787

# --- filebrowser: file manager web -------------------------------------
INSTALL_FILEBROWSER="1"              # 0 = lewati, 1 = pasang filebrowser
FILEBROWSER_VERSION="2.63.23"        # versi yang teruji
FILEBROWSER_PORT="8090"              # port listen (dipakai health-alert;
                                     # ganti port via: stop service,
                                     # filebrowser config set --port <n>)

# --- tailscale: VPN privat antar-mesin ------------------------------------
INSTALL_TAILSCALE="1"                # 0 = lewati, 1 = pasang tailscaled
TAILSCALE_VERSION="1.102.4"          # versi yang teruji di mesin asal
                                     # (static build linux-amd64 dari
                                     # pkgs.tailscale.com)
# Catatan: setelah install, DAFTAR manual (identity-bound, tidak bisa
# diotomatisasi): `tailscale up` lalu login di browser. Tanpa ini daemon
# jalan tapi tidak terhubung ke tailnet mana pun.

# --- hermes: Telegram gateway (OPT-IN) ----------------------------------
INSTALL_HERMES_GATEWAY="0"           # 1 = pasang unit hermes-gateway.service.
                                     # Butuh: CLI hermes + bot token & allowlist
                                     # dari tanganmu (lihat hermes/README.md).
                                     # Tidak ada kredensial yang ikut template.

# --- health alerts -------------------------------------------------------
INSTALL_HEALTH_ALERT="1"             # 1 = pasang health-alert.sh (dijalankan
                                     # di akhir tiap siklus keep.sh).
                                     # Alert Telegram hanya bila token bot ada
                                     # (dibaca dari file di bawah); bila tidak
                                     # ada, alert dilewatkan diam-diam.
HEALTH_ALERT_ENV="$HOME/.hermes/profiles/telegram/.env"
                                     # file env berisi TELEGRAM_BOT_TOKEN dan
                                     # TELEGRAM_ALLOWED_USERS (tidak ikut template)

# --- container Linux (opsional) --------------------------------------
INSTALL_CONTAINER="1"                # 0 = lewati, 1 = unduh & pasang ubuntu-base
UBUNTU_BASE_URL="http://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04-base-amd64.tar.gz"

# --- akhir override lokal --------------------------------------------
# (baris terakhir config.sh HARUS sukses: install.sh berjalan dengan
# `set -e`, dan `source` mengembalikan status perintah terakhir —
# tanpa `|| true`, instalasi gagal di mesin tanpa config.local.sh)
[ -f "$(dirname "${BASH_SOURCE[0]}")/config.local.sh" ] && source "$(dirname "${BASH_SOURCE[0]}")/config.local.sh" || true
