#!/usr/bin/env bash
# =====================================================================
# install.sh — installer muse-stack-template (idempoten, aman dijalankan ulang)
#
# Memasang:
#   1. 9router (via npm --prefix, path deterministik) + systemd unit
#   2. muse-bridge shim + systemd unit
#   3. caveman token-saver proxy + systemd unit (opsional)
#   4. headroom-ai[proxy] Token Saver + systemd unit (opsional)
#   5. filebrowser + systemd unit (opsional)
#   6. tailscale (VPN privat) + systemd unit (opsional)
#   7. API key 9router (disimpan di ~/workspace/9router-apikey.txt)
#   8. Provider Pollinations + Muse Bridge di DB 9router
#   9. hermes Telegram gateway + systemd unit (OPT-IN, butuh token user)
#  10. health-alert.sh (alert Telegram saat service down/pulih)
#  11. (opsional) container Linux ubuntu-base
#
# Yang TIDAK diotomatisasi (butuh runtime Muse target / tangan user):
#   - scheduled worker muse-bridge tiap 30 detik -> muse-bridge/HOOK-SETUP.md
#     (hook "muse-bridge-queue" hanya cadangan)
#   - cron keeper tiap 5 menit      -> lihat README.md
#   - `tailscale up` (login tailnet) -> butuh akun Tailscale user
#   - konfigurasi hermes CLI        -> lihat README.md / hermes/README.md
#   - bot token Telegram            -> lihat hermes/README.md
#   - aktifkan Headroom di dashboard 9router (Endpoint -> Token Saver)
#
# Butuh root (untuk /etc/systemd/system). Bila dijalankan sebagai user
# biasa, skrip mencoba sudo -E otomatis (menjaga $HOME).
# =====================================================================
set -euo pipefail

TEMPLATE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$TEMPLATE_DIR/config.sh"

usage() {
  cat <<EOF
Penggunaan: bash install.sh [--help]

Installer muse-stack-template: 9router + muse-bridge + provider gratis
Pollinations (+ caveman & headroom token-savers, filebrowser, health
alerts, dan opsional: hermes Telegram gateway & container Ubuntu).

  --help        tampilkan bantuan ini

Semua pilihan ada di config.sh (atau override via config.local.sh di
direktori yang sama — dibuat manual, tidak ikut template).
Installer idempoten: aman dijalankan ulang kapan saja; yang sudah
terpasang dilewati, yang belum dilengkapi.
EOF
}

if [ "${1:-}" = "--help" ] || [ "${1:-}" = "-h" ]; then
  usage
  exit 0
fi

if [ "$(id -u)" -ne 0 ]; then
  echo "[install] butuh root untuk systemd — mencoba sudo..."
  exec sudo -E "$0" "$@"
fi

[ -n "${HOME:-}" ] || { echo "[install] HOME kosong, batal."; exit 1; }
echo "[install] HOME=$HOME"

# --- 1. prasyarat -----------------------------------------------------
echo "[1/12] cek prasyarat"
for c in python3 sqlite3 node npm curl systemctl jq; do
  command -v "$c" >/dev/null || { echo "[install] perintah '$c' tidak ada — pasang dulu."; exit 1; }
done
NODE="$(command -v node)"
PYTHON="$(command -v python3)"
echo "      node=$NODE python=$PYTHON"

# --- 2. 9router -------------------------------------------------------
echo "[2/12] install 9router $NINEROUTER_VERSION"
APP="$HOME/workspace/9router-app"
if [ -x "$APP/node_modules/9router/cli.js" ]; then
  echo "      sudah ada, dilewati"
else
  mkdir -p "$APP"
  npm install --prefix "$APP" "9router@${NINEROUTER_VERSION}" --no-audit --no-fund
fi
[ -x "$APP/node_modules/9router/cli.js" ] || { echo "[install] cli.js 9router tidak ketemu"; exit 1; }

# --- 3. file muse-bridge ----------------------------------------------
echo "[3/12] file muse-bridge"
MB="$HOME/workspace/muse-bridge"
mkdir -p "$MB/queue" "$MB/responses"
cp "$TEMPLATE_DIR/muse-bridge/shim.py" "$MB/shim.py"
cp "$TEMPLATE_DIR/9router/ask-9router.sh" "$HOME/workspace/ask-9router.sh"
chmod +x "$HOME/workspace/ask-9router.sh"

# --- 4. caveman (opsional) ---------------------------------------------
echo "[4/12] caveman (INSTALL_CAVEMAN=$INSTALL_CAVEMAN)"
if [ "$INSTALL_CAVEMAN" = "1" ]; then
  # Biner standalone Go di ~/.caveman/bin (home = durable; /usr/bin hilang
  # saat VM diganti). `caveman start` (CLI node) SELALU daemonize — jangan
  # pernah dijalankan di bawah systemd; wrapper caveman-run.sh mengeksekusi
  # binernya langsung di foreground. Lihat caveman/README.md.
  CBIN="$HOME/.caveman/bin/caveman-proxy"
  if [ ! -x "$CBIN" ]; then
    echo "      biner caveman-proxy belum ada — pasang CLI, unduh biner sekali"
    command -v caveman >/dev/null 2>&1 || npm i -g "$CAVEMAN_NPM" --no-audit --no-fund
    # `caveman start` mengunduh biner standalone ke ~/.caveman/bin/; ia
    # daemonize, jadi jalankan sebentar lalu matikan lagi.
    (caveman start >/tmp/caveman-first-start.log 2>&1 &) || true
    for _ in $(seq 1 30); do [ -x "$CBIN" ] && break; sleep 2; done
    pkill -f "[c]aveman-proxy" 2>/dev/null || true
  else
    echo "      biner sudah ada, dilewati"
  fi
  [ -x "$CBIN" ] || echo "      WARN: biner caveman-proxy tidak muncul — unit akan gagal start; lihat caveman/README.md (langkah manual), lalu jalankan ulang install.sh"
  mkdir -p "$HOME/.caveman"
  if [ ! -f "$HOME/.caveman/caveman.yaml" ]; then
    sed -e "s|{{CAVEMAN_PORT}}|$CAVEMAN_PORT|g" \
      "$TEMPLATE_DIR/caveman/caveman.yaml" > "$HOME/.caveman/caveman.yaml"
    echo "      caveman.yaml ditulis (tidak menimpa yang sudah ada)"
  else
    echo "      caveman.yaml sudah ada, tidak ditimpa"
  fi
else
  echo "      dilewati"
fi

# --- 5. headroom (opsional) --------------------------------------------
echo "[5/12] headroom (INSTALL_HEADROOM=$INSTALL_HEADROOM)"
if [ "$INSTALL_HEADROOM" = "1" ]; then
  HV="$HOME/workspace/headroom-venv"
  if [ ! -x "$HV/bin/headroom" ]; then
    echo "      buat venv + pip install headroom-ai[proxy]"
    # WAJIB venv: pip system gagal (typing_extensions milik Debian, PEP 668).
    python3 -m venv "$HV"
    "$HV/bin/pip" install --quiet "headroom-ai[proxy]==$HEADROOM_VERSION"
  else
    echo "      sudah ada, dilewati"
  fi
else
  echo "      dilewati"
fi

# --- 6. filebrowser (opsional) ------------------------------------------
echo "[6/12] filebrowser (INSTALL_FILEBROWSER=$INSTALL_FILEBROWSER)"
if [ "$INSTALL_FILEBROWSER" = "1" ]; then
  FB="$HOME/workspace/filebrowser"
  FBIN="$FB/bin/filebrowser"
  mkdir -p "$FB/bin"
  if [ ! -x "$FBIN" ]; then
    echo "      unduh filebrowser v$FILEBROWSER_VERSION ke lokasi durable"
    # Lokasi durable: ~/workspace/... — BUKAN /usr/local/bin (hilang saat VM diganti).
    curl -L -o /tmp/fb.tar.gz \
      "https://github.com/filebrowser/filebrowser/releases/download/v${FILEBROWSER_VERSION}/linux-amd64-filebrowser.tar.gz"
    tar -xzf /tmp/fb.tar.gz -C "$FB/bin" filebrowser
    chmod +x "$FBIN"
    rm -f /tmp/fb.tar.gz
  else
    echo "      biner sudah ada, dilewati"
  fi
  if [ ! -f "$FB/filebrowser.db" ]; then
    echo "      init DB + user admin"
    ( cd "$FB" && "$FBIN" config init >/dev/null 2>&1 )
    FBPW="$(python3 -c 'import secrets; print(secrets.token_urlsafe(24))')"
    ( cd "$FB" && "$FBIN" users add admin "$FBPW" --perm.admin --scope "$HOME" )
    printf '%s' "$FBPW" > "$FB/.admin-pw"
    chmod 600 "$FB/.admin-pw"
    echo "      kredensial admin di $FB/.admin-pw (mode 600, jangan dishare)"
  else
    echo "      DB sudah ada, dilewati"
  fi
else
  echo "      dilewati"
fi

# --- 7. tailscale (opsional) ------------------------------------------------
echo "[7/12] tailscale (INSTALL_TAILSCALE=$INSTALL_TAILSCALE)"
if [ "$INSTALL_TAILSCALE" = "1" ]; then
  TS="$HOME/workspace/tailscale"
  mkdir -p "$TS"
  if [ ! -x "$TS/tailscaled" ]; then
    echo "      unduh tailscale v$TAILSCALE_VERSION (static build linux-amd64)"
    # Lokasi durable: ~/workspace/... — biner statik, tanpa dependensi.
    curl -L -o /tmp/ts.tgz \
      "https://pkgs.tailscale.com/stable/tailscale_${TAILSCALE_VERSION}_linux_amd64.tgz"
    tar -xzf /tmp/ts.tgz -C /tmp
    cp "/tmp/tailscale_${TAILSCALE_VERSION}_linux_amd64/tailscaled" \
       "/tmp/tailscale_${TAILSCALE_VERSION}_linux_amd64/tailscale" "$TS/"
    chmod +x "$TS/tailscaled" "$TS/tailscale"
    rm -rf /tmp/ts.tgz "/tmp/tailscale_${TAILSCALE_VERSION}_linux_amd64"
  else
    echo "      biner sudah ada, dilewati"
  fi
  [ -x "$TS/tailscaled" ] || echo "      WARN: biner tailscaled tidak muncul — unit akan gagal start"
else
  echo "      dilewati"
fi

# --- 8. unit systemd ---------------------------------------------------
echo "[8/12] unit systemd + keep.sh + health-alert.sh"
SD="$HOME/workspace/systemd"
mkdir -p "$SD"
render() { # render <template> <output>
  sed -e "s|{{HOME}}|$HOME|g" \
      -e "s|{{NODE}}|$NODE|g" \
      -e "s|{{PYTHON}}|$PYTHON|g" \
      -e "s|{{NINEROUTER_PORT}}|$NINEROUTER_PORT|g" \
      -e "s|{{SHIM_PORT}}|$SHIM_PORT|g" \
      -e "s|{{BRIDGE_PREFIX}}|$BRIDGE_PREFIX|g" \
      -e "s|{{CAVEMAN_PORT}}|$CAVEMAN_PORT|g" \
      -e "s|{{HEADROOM_PORT}}|$HEADROOM_PORT|g" \
      -e "s|{{FILEBROWSER_PORT}}|$FILEBROWSER_PORT|g" \
      "$1" > "$2"
}
render "$TEMPLATE_DIR/systemd/9router.service"   "$SD/9router.service"
render "$TEMPLATE_DIR/systemd/muse-shim.service" "$SD/muse-shim.service"
render "$TEMPLATE_DIR/systemd/container-app@.service" "$SD/container-app@.service"
if [ "$INSTALL_CAVEMAN" = "1" ]; then
  render "$TEMPLATE_DIR/systemd/caveman.service" "$SD/caveman.service"
  cp "$TEMPLATE_DIR/systemd/caveman-run.sh" "$SD/caveman-run.sh"
  chmod +x "$SD/caveman-run.sh"
fi
if [ "$INSTALL_HEADROOM" = "1" ]; then
  render "$TEMPLATE_DIR/systemd/headroom.service" "$SD/headroom.service"
fi
if [ "$INSTALL_FILEBROWSER" = "1" ]; then
  render "$TEMPLATE_DIR/systemd/filebrowser.service" "$SD/filebrowser.service"
fi
if [ "$INSTALL_TAILSCALE" = "1" ]; then
  render "$TEMPLATE_DIR/systemd/tailscaled.service" "$SD/tailscaled.service"
fi
cp "$TEMPLATE_DIR/systemd/keep.sh" "$SD/keep.sh"
chmod +x "$SD/keep.sh"
if [ "$INSTALL_HEALTH_ALERT" = "1" ]; then
  # health-alert.sh di-render (port dari config.sh), bukan cp mentah
  render "$TEMPLATE_DIR/systemd/health-alert.sh" "$SD/health-alert.sh"
  chmod +x "$SD/health-alert.sh"
fi
bash "$SD/keep.sh"

# --- 9. tunggu 9router + API key ---------------------------------------
echo "[9/12] API key 9router"
DB="$HOME/.9router/db/data.sqlite"
for _ in $(seq 1 30); do
  [ -f "$DB" ] && break
  sleep 2
done
[ -f "$DB" ] || { echo "[install] DB 9router tidak muncul: $DB"; exit 1; }

KEY="$(sqlite3 "$DB" "SELECT key FROM apiKeys WHERE isActive=1 LIMIT 1;" 2>/dev/null || true)"
KEY_CREATED=0
if [ -z "$KEY" ]; then
  KEY="sk-9router-$(python3 -c 'import secrets; print(secrets.token_hex(16))')"
  sqlite3 "$DB" "INSERT INTO apiKeys (id, key, name, isActive, createdAt) VALUES \
    ('$(python3 -c 'import uuid; print(uuid.uuid4())')', '$KEY', 'template-install', 1, datetime('now'));"
  KEY_CREATED=1
  echo "      key baru dibuat"
else
  echo "      key aktif sudah ada, dipakai ulang"
fi
printf '%s' "$KEY" > "$HOME/workspace/9router-apikey.txt"
chmod 600 "$HOME/workspace/9router-apikey.txt"
echo "      tersimpan di ~/workspace/9router-apikey.txt (jangan dishare)"
if [ "$KEY_CREATED" = "1" ]; then
  # 9router mungkin meng-cache API key di memori — restart agar key baru terbaca
  systemctl restart 9router
  echo "      9router di-restart agar key baru aktif"
fi

# --- 10. registrasi provider --------------------------------------------
echo "[10/12] registrasi provider (Pollinations + Muse Bridge)"
# USE_CAVEMAN=1 -> node Pollinations lewat caveman proxy lokal.
# (Node yang SUDAH terdaftar tidak diubah — idempoten. Untuk migrasi node
# lama: ubah baseUrl di dashboard 9router atau hapus node lalu rerun.)
if [ "$USE_CAVEMAN" = "1" ]; then
  POLL_BASE_URL="http://127.0.0.1:${CAVEMAN_PORT}/v1"
  echo "      Pollinations via caveman: $POLL_BASE_URL"
fi
NINEROUTER_DB="$DB" \
BRIDGE_PREFIX="$BRIDGE_PREFIX" BRIDGE_NAME="$BRIDGE_NAME" SHIM_PORT="$SHIM_PORT" \
POLL_PREFIX="$POLL_PREFIX" POLL_NAME="$POLL_NAME" POLL_BASE_URL="$POLL_BASE_URL" \
POLL_MODELS="$POLL_MODELS" \
  python3 "$TEMPLATE_DIR/9router/register-providers.py"

# --- 11. hermes telegram gateway (OPT-IN) --------------------------------
echo "[11/12] hermes telegram gateway (INSTALL_HERMES_GATEWAY=$INSTALL_HERMES_GATEWAY)"
if [ "$INSTALL_HERMES_GATEWAY" = "1" ]; then
  if ! command -v hermes >/dev/null 2>&1; then
    echo "      WARN: CLI hermes tidak ada — lewati (lihat hermes/README.md)"
  else
    HP="$HOME/.hermes/profiles/telegram"
    mkdir -p "$HP"
    if [ ! -f "$HP/config.yaml" ]; then
      sed -e "s|{{BRIDGE_PREFIX}}|$BRIDGE_PREFIX|g" \
          -e "s|{{NINEROUTER_PORT}}|$NINEROUTER_PORT|g" \
        "$TEMPLATE_DIR/hermes/telegram-config.yaml" > "$HP/config.yaml"
      echo "      config.yaml profil telegram ditulis"
    else
      echo "      config.yaml profil telegram sudah ada, tidak ditimpa"
    fi
    if [ ! -f "$HP/profile.yaml" ]; then
      sed -e "s|{{BRIDGE_PREFIX}}|$BRIDGE_PREFIX|g" \
        "$TEMPLATE_DIR/hermes/profile.yaml" > "$HP/profile.yaml"
    fi
    if [ ! -f "$HP/.env" ]; then
      cp "$TEMPLATE_DIR/hermes/.env.example" "$HP/.env"
      chmod 600 "$HP/.env"
      echo "      !!! ISI $HP/.env (TELEGRAM_BOT_TOKEN & TELEGRAM_ALLOWED_USERS) — tanpa ini gateway tidak jalan"
    fi
    render "$TEMPLATE_DIR/systemd/hermes-gateway.service" "$SD/hermes-gateway.service"
    bash "$SD/keep.sh"   # pasang + start unit hermes-gateway
  fi
else
  echo "      dilewati (opt-in; lihat hermes/README.md)"
fi

# --- 12. container linux (opsional) --------------------------------------
echo "[12/12] container linux (INSTALL_CONTAINER=$INSTALL_CONTAINER)"
if [ "$INSTALL_CONTAINER" = "1" ]; then
  LB="$HOME/workspace/linux-big-disk"
  mkdir -p "$LB"
  TARBALL="$LB/ubuntu-base.tar.gz"
  if [ ! -f "$TARBALL" ]; then
    echo "      unduh ubuntu-base..."
    curl -L -o "$TARBALL" "$UBUNTU_BASE_URL"
  fi
  if [ ! -f "$LB/rootfs/etc/os-release" ]; then
    echo "      ekstrak rootfs..."
    mkdir -p "$LB/rootfs"
    tar -xzf "$TARBALL" -C "$LB/rootfs"
  fi
  cp "$TEMPLATE_DIR/container/enter.sh" "$LB/enter.sh"
  chmod +x "$LB/enter.sh"
  echo "      masuk: bash $LB/enter.sh"
else
  echo "      dilewati"
fi

# --- selesai -------------------------------------------------------------
cat <<EOF

[install] SELESAI. Status layanan:
EOF
systemctl --no-pager status 9router muse-shim 2>/dev/null | grep -E '●|Active:' || true
cat <<EOF

Langkah MANUAL yang tersisa (tidak bisa diotomatisasi dari shell):
  1. Scheduled worker muse-bridge tiap 30 detik -> muse-bridge/HOOK-SETUP.md
     (jalur utama; hook "muse-bridge-queue" hanya cadangan)
  2. Cron keeper tiap 5 menit -> README.md bagian "Auto-restart"
     (bash ~/workspace/systemd/keep.sh)
  3. Aktifkan Headroom di dashboard 9router: Endpoint -> Token Saver ->
     Headroom -> http://localhost:$HEADROOM_PORT  (bila INSTALL_HEADROOM=1)
  4. Tailscale: ~/workspace/tailscale/tailscale up  (bila INSTALL_TAILSCALE=1;
     butuh login akun Tailscale-mu di browser)
  5. Hermes/Telegram (bila dipakai) -> hermes/README.md
     (butuh TELEGRAM_BOT_TOKEN + TELEGRAM_ALLOWED_USERS dari tanganmu)

Tes cepat (setelah hook aktif):
  bash ~/workspace/ask-9router.sh "halo"
  curl -s http://localhost:$NINEROUTER_PORT/v1/chat/completions \\
    -H "Content-Type: application/json" \\
    -H "Authorization: Bearer \$(cat ~/workspace/9router-apikey.txt)" \\
    -d '{"model":"'"$BRIDGE_PREFIX"'/agent","messages":[{"role":"user","content":"siapa kamu?"}]}'
EOF
