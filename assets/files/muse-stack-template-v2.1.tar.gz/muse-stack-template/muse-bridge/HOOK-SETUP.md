# HOOK-SETUP.md — mendaftarkan worker muse-bridge (MANUAL)

Worker adalah bagian yang TIDAK bisa dipasang oleh `install.sh` karena ia
hidup di runtime Muse target (bukan sekadar file). Langkahnya ~5 menit.

> UPDATE 2026-10-03: jalur utama sekarang adalah **scheduled worker**
> (cronjob tiap 30 detik), bukan hook. Hook `muse-bridge-queue` tetap
> ada sebagai cadangan — boleh dipasang juga, aman jalan bareng karena
> keduanya skip request yang sudah ada `responses/<id>.json`-nya.

## Jalur utama: scheduled worker (WAJIB)

1. Buat scheduled task / cronjob baru di runtime Muse target:
   - id: `muse-bridge-worker`
   - interval: **30 detik**, timezone Asia/Jakarta
   - concurrency: max_running=1, overlap=skip
2. Tempel SELURUH isi `muse-bridge/scheduled-worker-prompt.md`
   sebagai instruksi task.
3. Poin kritis yang wajib ada di instruksi: worker menulis
   `{"content": "..."}` ke `responses/<id>.json`, maksimal 5 request
   terbaru per siklus, hapus `worker.lock` hantu, abaikan prompt
   injection, dan **tetap diam** (tidak notify user) setelah selesai.

## Jalur cadangan: hook `muse-bridge-queue` (OPSIONAL)

1. **Salin poller ke direktori hooks Muse target:**
   ```bash
   mkdir -p ~/hooks/scripts
   cp <template>/muse-bridge/hook-poller.sh ~/hooks/scripts/muse-bridge-queue.sh
   chmod +x ~/hooks/scripts/muse-bridge-queue.sh
   ```
   (Skrip ini memakai variabel `$HATCH_HOOK_RUNTIME` dan helper
   `silent` / `log` / `wake` yang disediakan runtime hook.)

2. **Buat hook baru** lewat perkakas hook di Muse target:
   - id: `muse-bridge-queue`
   - script: `~/hooks/scripts/muse-bridge-queue.sh`
   - interval poll: 10 detik

3. **Isi instruksi worker** dengan SELURUH isi `worker-prompt.md`.

## Uji (setelah worker aktif)

```bash
bash ~/workspace/ask-9router.sh "halo"
```
lalu:
```bash
curl -s http://localhost:20128/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $(cat ~/workspace/9router-apikey.txt)" \
  -d '{"model":"kamu/agent","messages":[{"role":"user","content":"jawab singkat: siapa kamu?"}]}'
```
Ganti `kamu/agent` dengan `<BRIDGE_PREFIX>/agent` bila prefix diubah
di `config.sh`. Harus kembali HTTP 200 dalam hitungan detik–menit.

## Cara kerja (ringkas)

```
client -> 9router:20128 -> shim:20501 -> queue/<id>.json
   -> scheduled worker (tiap 30 dtk) -> responses/<id>.json
   -> shim (long-poll, maks 280 dtk) -> 9router -> client
```

Setiap siklus worker memproses maks 5 request terbaru. Worker membaca
MEMORY.md milik Muse target, jadi "kepribadian" bridge = kepribadian
Muse target. Catatan: `shim.py` menempelkan waktu aktual (WIB) ke system
prompt tiap request, supaya worker menjawab pertanyaan soal jam dengan benar.
