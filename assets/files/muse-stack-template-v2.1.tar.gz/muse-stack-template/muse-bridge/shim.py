#!/usr/bin/env python3
"""muse-bridge shim — OpenAI-compatible endpoint di depan worker agent Muse.

9router didaftarkan custom provider node ke http://127.0.0.1:20501/v1
(prefix "muse"). Tiap POST /v1/chat/completions ditulis ke queue/ sebagai
<id>.json, lalu koneksi ditahan (long-poll) sampai hook worker agent menulis
responses/<id>.json berisi {"content": "..."} atau {"error": "..."}.

Jalankan via muse-bridge-supervisor.sh (detached loop), bukan manual.
"""
import json
import os
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse

BASE = os.path.expanduser("~/workspace/muse-bridge")
QUEUE = os.path.join(BASE, "queue")
RESP = os.path.join(BASE, "responses")
LOG = os.path.join(BASE, "shim.log")
PORT = int(os.environ.get("BRIDGE_SHIM_PORT", "20501"))  # bisa dioverride via env
WAIT_TIMEOUT = 280  # detik nunggu worker agent
MODEL_ID = "agent"  # 9router menampilkannya sebagai <prefix>/agent

os.makedirs(QUEUE, exist_ok=True)
os.makedirs(RESP, exist_ok=True)


def log(msg):
    try:
        with open(LOG, "a") as f:
            f.write("[%s] %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    except Exception:
        pass


class Handler(BaseHTTPRequestHandler):
    server_version = "muse-bridge/1.0"

    def log_message(self, *a):
        pass

    def _send_json(self, obj, code=200):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        if path in ("/v1/models", "/models"):
            self._send_json({
                "object": "list",
                "data": [{
                    "id": MODEL_ID,
                    "object": "model",
                    "created": int(time.time()),
                    "owned_by": "muse-bridge",
                }],
            })
        elif path in ("/health", "/v1/health", ""):
            self._send_json({"status": "ok", "queue": self._pending_count()})
        else:
            self._send_json({"error": {"message": "not found", "type": "not_found"}}, 404)

    def do_POST(self):
        path = urlparse(self.path).path.rstrip("/") or "/"
        if path not in ("/v1/chat/completions", "/chat/completions"):
            self._send_json({"error": {"message": "not found", "type": "not_found"}}, 404)
            return
        try:
            length = int(self.headers.get("Content-Length", 0) or 0)
        except ValueError:
            length = 0
        if length <= 0 or length > 2_000_000:
            self._send_json({"error": {"message": "bad content length", "type": "invalid_request"}}, 400)
            return
        try:
            req = json.loads(self.rfile.read(length) or b"{}")
        except Exception:
            self._send_json({"error": {"message": "invalid json", "type": "invalid_request"}}, 400)
            return

        rid = uuid.uuid4().hex[:16]
        stream = bool(req.get("stream"))
        model = req.get("model", MODEL_ID)
        # Konteks waktu: system time VM sudah Asia/Jakarta, tapi worker yang jawab
        # tidak punya jam asli — tempelkan waktu aktual agar jawaban soal jam benar.
        try:
            msgs = req.get("messages") or []
            if msgs and msgs[0].get("role") == "system" and isinstance(msgs[0].get("content"), str):
                now_wib = time.strftime("%Y-%m-%d %H:%M", time.localtime())
                msgs[0]["content"] += "\n\n[Sistem: waktu saat ini %s WIB (Asia/Jakarta).]" % now_wib
        except Exception:
            pass
        try:
            with open(os.path.join(QUEUE, rid + ".json"), "w") as f:
                json.dump({"id": rid, "received_at": time.time(), "request": req}, f)
        except Exception as e:
            self._send_json({"error": {"message": "queue write failed: %s" % e, "type": "bridge_error"}}, 500)
            return
        log("queued %s model=%s stream=%s msgs=%d" % (rid, model, stream, len(req.get("messages", []) or [])))

        resp_path = os.path.join(RESP, rid + ".json")
        deadline = time.time() + WAIT_TIMEOUT
        result = None
        while time.time() < deadline:
            if os.path.exists(resp_path):
                try:
                    with open(resp_path) as f:
                        result = json.load(f)
                    break
                except Exception:
                    pass
            time.sleep(2)

        if result is None:
            log("timeout %s" % rid)
            self._send_json({"error": {"message": "bridge timeout: worker agent tidak merespons tepat waktu", "type": "timeout"}}, 504)
            return
        if result.get("error"):
            log("worker error %s: %s" % (rid, str(result.get("error"))[:120]))
            self._send_json({"error": {"message": str(result["error"]), "type": "bridge_error"}}, 500)
            return

        content = result.get("content", "") or ""
        log("answered %s (%d chars)" % (rid, len(content)))
        if stream:
            self._send_sse(rid, model, content)
        else:
            self._send_json({
                "id": "chatcmpl-" + rid,
                "object": "chat.completion",
                "created": int(time.time()),
                "model": model,
                "choices": [{
                    "index": 0,
                    "message": {"role": "assistant", "content": content},
                    "finish_reason": "stop",
                }],
                "usage": {"prompt_tokens": 0, "completion_tokens": 0, "total_tokens": 0},
            })

    def _send_sse(self, rid, model, content):
        try:
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.end_headers()
            base = {
                "id": "chatcmpl-" + rid,
                "object": "chat.completion.chunk",
                "created": int(time.time()),
                "model": model,
            }
            first = dict(base)
            first["choices"] = [{"index": 0, "delta": {"role": "assistant", "content": content}, "finish_reason": None}]
            self.wfile.write(("data: " + json.dumps(first) + "\n\n").encode("utf-8"))
            last = dict(base)
            last["choices"] = [{"index": 0, "delta": {}, "finish_reason": "stop"}]
            self.wfile.write(("data: " + json.dumps(last) + "\n\n").encode("utf-8"))
            self.wfile.write(b"data: [DONE]\n\n")
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _pending_count(self):
        try:
            q = {f[:-5] for f in os.listdir(QUEUE) if f.endswith(".json")}
            r = {f[:-5] for f in os.listdir(RESP) if f.endswith(".json")}
            return len(q - r)
        except Exception:
            return -1


if __name__ == "__main__":
    server = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    server.daemon_threads = True
    log("shim listening on 127.0.0.1:%d" % PORT)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
