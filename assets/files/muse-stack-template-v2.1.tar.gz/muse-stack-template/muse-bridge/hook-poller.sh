#!/usr/bin/env bash
# muse-bridge-queue.sh — hook poller: cek antrean request muse-bridge tiap poll,
# wake worker agent kalau ada request yang belum dijawab dan belum ada worker jalan.
set -euo pipefail
source "$HATCH_HOOK_RUNTIME"

Q="$HOME/workspace/muse-bridge/queue"
R="$HOME/workspace/muse-bridge/responses"
LOCK="$HOME/workspace/muse-bridge/worker.lock"

pending=()
if [ -d "$Q" ]; then
  for f in "$Q"/*.json; do
    [ -e "$f" ] || continue
    id="$(basename "$f" .json)"
    [ -f "$R/$id.json" ] && continue
    pending+=("$id")
  done
fi

if [ "${#pending[@]}" -eq 0 ]; then
  silent "no pending bridge requests"
elif [ -f "$LOCK" ]; then
  # lock basi (>10 menit) dianggap worker mati — hapus supaya request tidak nyangkut
  if [ "$(( $(date +%s) - $(stat -c %Y "$LOCK" 2>/dev/null || echo 0) ))" -gt 600 ]; then
    rm -f "$LOCK"
    log "removed stale worker lock"
    ids="$(IFS=,; echo "${pending[*]}")"
    wake "muse-bridge requests pending (stale lock cleared): $ids" "{\"ids\":\"$ids\"}"
  else
    silent "worker already running, ${#pending[@]} request(s) queued"
  fi
else
  ids="$(IFS=,; echo "${pending[*]}")"
  wake "muse-bridge requests pending: $ids" "{\"ids\":\"$ids\"}"
fi
