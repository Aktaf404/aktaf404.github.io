# PRD: muse-stack-template — Paket Instalasi Portabel Stack 9router + muse-bridge

**Status:** Implemented & validated (2026-10-01), diperbarui ke kondisi 2026-10-03
**Isi paket:** `muse-stack-template.tar.gz` (lihat §12)
**Versi dokumen:** 2.1 (2026-10-03 sore — sinkronisasi dengan produksi)

---

## 1. Ringkasan Eksekutif

`muse-stack-template` adalah paket instalasi portabel yang mereproduksi
**seluruh stack yang sudah teruji jalan** di satu Muse ke Muse lain
(akun/email berbeda): gateway 9router, jembatan muse-bridge
(model `kamu/agent`), provider gratis Pollinations, unit systemd +
keeper auto-restart, dan container Ubuntu.

Prinsip desain: **installer idempoten** (`install.sh` aman dijalankan
ulang), **tanpa kredensial bawaan** (API key di-generate fresh per
instalasi), dan **jujur soal batas** — langkah yang hidup di runtime
Muse target / tangan user (scheduled worker, cron keeper, `tailscale up`,
konfigurasi Hermes) didokumentasikan sebagai prosedur manual, bukan
disembunyikan.

Hasil validasi: sintaks seluruh skrip lolos; render unit systemd bersih;
`register-providers.py` idempoten dan lolos uji DB fresh (menemukan &
memperbaiki satu bug nyata: kolom `scope` di tabel `kv`); shim lolos
smoke test di port custom via env var; instalasi 9router via
`npm --prefix` teruji menghasilkan path deterministik.

**v2.0 (2026-10-03):** template di-rebuild agar mencerminkan kondisi
instalasi asal saat ini — tambah caveman proxy, headroom-ai[proxy],
filebrowser, hermes Telegram gateway (opt-in), health-alert.sh;
`keep.sh` kini mengelola 7 unit + env proxy + timezone + health check;
`shim.py` mendapat injeksi konteks waktu WIB; `install.sh` mendapat
flag `--help` dan fase instalasi baru (11 fase). Prinsip tetap:
idempoten, placeholder `{{...}}`, tanpa kredensial bawaan.

**v2.1 (2026-10-03 sore):** sinkronisasi dengan instalasi produksi —
worker utama kini **scheduled worker tiap 30 detik** (hook jadi cadangan,
`scheduled-worker-prompt.md` baru); `health-alert.sh` diganti ke versi
produksi yang terbukti mengirim alert down/pulih (port di-render dari
`config.sh`, hanya cek unit yang terpasang); `keep.sh` dapat blok
`tailscaled.env` + komentar timezone yang lebih akurat; unit
**`tailscaled.service`** baru + `INSTALL_TAILSCALE` di
`config.sh`/`install.sh` (12 fase); `hermes/.env.example` dibersihkan;
`EnvironmentFile` unit ber-proxy diberi prefix `-` (opsional) agar
tetap jalan di mesin tanpa proxy egress.

---

## 2. Latar Belakang & Masalah

1. Stack dibangun secara inkremental di satu Muse: 9router v0.5.95
   sebagai gateway lokal → provider gratis Pollinations → muse-bridge
   (shim + hook + worker agent, model `kamu/agent`) → systemd units +
   `keep.sh` + cron keeper untuk auto-restart → container Ubuntu
   `linux-big-disk`.
2. Pengguna meminta: *"buatin template … bisa dibaca dan dipasang di
   muse lain dengan beda email, mau coba terapin beneran bisa ga"*.
3. Instalasi asli tidak portabel apa adanya: path npx memakai hash acak
   per mesin (`~/.npm/_npx/<hash>/…`), UUID node di-generate sekali,
   port hardcode di `shim.py`, dan API key 9router spesifik instalasi.
4. Template ini menjawabnya dengan memisahkan **yang berupa file**
   (ikut paket) dari **yang hidup di runtime** (prosedur manual).

---

## 3. Tujuan

1. Satu perintah (`bash install.sh`) memasang 9router + muse-bridge +
   provider + systemd units + container di Muse target.
2. Hasil instalasi **fungsional setara**: `kamu/agent` menjawab sebagai
   Muse target; `pllns/*` menjawab via Pollinations; crash & VM reset
   pulih otomatis.
3. Tidak ada kredensial yang ikut paket; tidak ada asumsi tentang email
   akun target.
4. Dokumentasi cukup lengkap sehingga instalasi bisa dilakukan tanpa
   bertanya kembali.

## 4. Ruang Lingkup

**Masuk:**
- `install.sh` (11 fase, idempoten, flag `--help`) + `config.sh` (+ override
  `config.local.sh`)
- `9router/register-providers.py` — registrasi node, connection, dan
  model custom ke `~/.9router/db/data.sqlite`
- `muse-bridge/shim.py` (port via env `BRIDGE_SHIM_PORT`, injeksi konteks
  waktu WIB), `scheduled-worker-prompt.md` (worker utama, cron 30 dtk),
  `hook-poller.sh` + `worker-prompt.md` (hook cadangan), `HOOK-SETUP.md`
- Template unit systemd (`9router.service`, `muse-shim.service`,
  `caveman.service` + `caveman-run.sh`, `headroom.service`,
  `filebrowser.service`, `tailscaled.service`,
  `hermes-gateway.service` (opt-in),
  `container-app@.service`) + `keep.sh` + `health-alert.sh` (di-render)
- `caveman/` (config `caveman.yaml` template + README: pelajaran daemonize
  & npm-ephemeral), `headroom/` (README: venv caveat PEP 668),
  `filebrowser/` (README: lokasi durable & prosedur scope/port),
  `hermes/` (`telegram-config.yaml` + `profile.yaml` + `.env.example` + README)
- `container/enter.sh` + unduhan ubuntu-base
- `9router/ask-9router.sh` (helper uji)
- Dokumen: `README.md`, `PORTABILITY.md`, PRD ini

**Keluar (tidak dikerjakan):**
- Pendaftaran hook & pembuatan cron keeper — hanya bisa dilakukan dari
  dalam runtime Muse target (prosedur manual disediakan)
- Jalur Meta Model API (terblokir kredensial di lingkungan ini)
- Dukungan OS selain Linux+systemd, dan arsitektur selain x86_64
  (belum diuji)
- Membuat VM "tidak bisa hilang" — tidak mungkin di platform ini;
  desain yang dibawa adalah *pulih cepat* (±5 menit)

---

## 5. Arsitektur Hasil Instalasi

```
Hermes/client --HTTP--> 9router:20128 --HTTP--> shim:20501
   shim tulis queue/<id>.json, long-poll (maks 280 dtk)
   scheduled worker (cron 30 dtk, jalur utama) jawab & tulis responses/<id>.json
   hook muse-bridge-queue (poll 10 dtk, cadangan) — aman jalan bareng, skip duplikat
   worker baca MEMORY.md target, tulis responses/<id>.json {"content": "..."}
   shim baca response --> 9router --> client

pllns/* : 9router:20128 --HTTP--> caveman:8788 --HTTP--> text.pollinations.ai/openai
   (kamu/agent SENGAJA tidak lewat caveman — langsung ke shim)

systemd: 9router.service, muse-shim.service, caveman.service, headroom.service,
         filebrowser.service, tailscaled.service (+ hermes-gateway.service bila opt-in),
         Restart=always; template container-app@.service untuk aplikasi chroot
cron (tiap 5 mnt): bash ~/workspace/systemd/keep.sh
   -> pasang ulang unit yang hilang/berubah, enable, pastikan aktif
   -> pastikan timezone Asia/Jakarta, generate hermes-gateway.env + tailscaled.env (proxy egress)
   -> jalankan health-alert.sh: cek unit + port, alert Telegram hanya saat
      transisi down/pulih (dedup via health-alert.state)
```

Model publik: `<BRIDGE_PREFIX>/agent` (default `kamu/agent`),
`pllns/gpt-oss`, `pllns/openai-fast` (via caveman bila `USE_CAVEMAN=1`).

---

## 6. Alur Instalasi (`install.sh`)

| Fase | Aksi | Idempoten? |
|---|---|---|
| 1. Prasyarat | cek `python3 sqlite3 node npm curl jq systemctl`; butuh root (auto `sudo -E`) | ya |
| 2. 9router | `npm install --prefix ~/workspace/9router-app 9router@<versi>` → path deterministik `…/node_modules/9router/cli.js` (menghindari hash acak npx) | ya (dilewati bila `cli.js` ada) |
| 3. File bridge | salin `shim.py`, buat `queue/` & `responses/`, salin `ask-9router.sh` | ya |
| 4. Caveman | `npm i -g @caveman-ai/cli`, `caveman start` sekali untuk mengunduh biner standalone ke `~/.caveman/bin/` (daemon dimatikan lagi); tulis `~/.caveman/caveman.yaml` bila belum ada | ya (dilewati bila biner ada) |
| 5. Headroom | `python3 -m venv ~/workspace/headroom-venv` + `pip install "headroom-ai[proxy]==<versi>"` (wajib venv: pip system ditolak PEP 668) | ya (dilewati bila `bin/headroom` ada) |
| 6. FileBrowser | unduh tarball release ke `~/workspace/filebrowser/bin/` (**durable**, bukan `/usr/local/bin`); `config init` + `users add admin` (password generate, `chmod 600 .admin-pw`) | ya (dilewati bila DB ada) |
| 7. Tailscale | unduh static build `tailscale_<versi>_linux_amd64.tgz` dari `pkgs.tailscale.com/stable/` → `~/workspace/tailscale/` (**durable**) | ya (dilewati bila biner ada) |
| 8. Unit systemd | render placeholder `{{HOME}} {{NODE}} {{PYTHON}} {{NINEROUTER_PORT}} {{SHIM_PORT}} {{BRIDGE_PREFIX}} {{CAVEMAN_PORT}} {{HEADROOM_PORT}} {{FILEBROWSER_PORT}}` → `~/workspace/systemd/` (termasuk `tailscaled.service` bila `INSTALL_TAILSCALE=1`); salin `keep.sh`; **render** `health-alert.sh` (port dari `config.sh`); jalankan `keep.sh` | ya |
| 9. API key | tunggu DB 9router; pakai key aktif bila ada, else generate `sk-9router-<hex>` + INSERT ke `apiKeys`; simpan ke `~/workspace/9router-apikey.txt` (600); restart 9router bila key baru | ya |
| 10. Provider | `register-providers.py`: node+connection bridge & Pollinations, model custom via `kv` (`scope='customModels'`, key `{prefix}\|{model}\|llm`). `USE_CAVEMAN=1` → `POLL_BASE_URL=http://127.0.0.1:8788/v1` | ya (cek prefix; node lama tidak diubah) |
| 11. Hermes gateway | **opt-in** (`INSTALL_HERMES_GATEWAY=1`): salin `telegram-config.yaml` + `profile.yaml` ke `~/.hermes/profiles/telegram/` (tidak menimpa), buat `.env` dari `.env.example` (600, **diisi manual**), render unit | ya |
| 12. Container | unduh & ekstrak ubuntu-base → `~/workspace/linux-big-disk/rootfs`, salin `enter.sh` | ya (flag `INSTALL_CONTAINER`) |

**Langkah manual pasca-install (±10 menit):** scheduled worker 30 dtk
(`muse-bridge/HOOK-SETUP.md`), cron keeper, `tailscale up`, konfigurasi
Hermes (`README.md`).

---

## 7. Keputusan Desain Penting

1. **`npm --prefix` bukan npx** — cache npx memakai hash direktori acak
   per mesin; `--prefix` memberi path deterministik yang bisa ditulis di
   unit systemd. (npx juga butuh ±45 dtk resolve & kadang hang di bawah
   systemd.)
2. **Prefix `kamu`, bukan `muse`** — `muse` tabrakan dengan provider
   built-in 9router (Meta Model API) → routing gagal
   ("No active credentials for provider: muse").
3. **Model bridge tanpa entri `kv`** — 9router mem-strip prefix lalu
   mem-forward model `agent` ke shim; instalasi teruji berjalan tanpa
   baris `kv` untuk bridge.
4. **API key per-instalasi** — tidak dibundel; installer generate baru.
   Key hanya dipakai untuk auth lokal 9router (`127.0.0.1`).
5. **Bridge = worker fresh, bukan sesi live** — tiap request = satu
   worker run yang baca `MEMORY.md` target. Di Muse lain, "kepribadian"
   bridge = kepribadian Muse target tersebut.
6. **Caveman sebagai upstream optimizer, bukan sidecar umum** — 9router
   → caveman (`:8788`) → Pollinations. Node `kamu/agent` SENGAJA tidak
   lewat caveman (jangan ganggu gateway yang sudah jalan). Jangan
   arahkan upstream caveman ke 9router (loop).
7. **`caveman start` tidak pernah di bawah systemd** — CLI selalu
   daemonize → restart-loop. Unit memakai wrapper `caveman-run.sh` yang
   `exec` biner Go foreground langsung; tidak bergantung pada CLI node
   (ephemeral).
8. **Lokasi biner = home, bukan /usr/local** — `/usr/local/bin`
   hilang saat VM diganti (filebrowser sempat `exit 203/EXEC`
   karenanya); `~/workspace/...` dan `~/.caveman/` persisten.
9. **venv untuk paket Python** — `pip` system gagal di Debian
   (PEP 668, `typing_extensions` milik distro); headroom dipasang di
   `~/workspace/headroom-venv/`.
10. **Gateway hermes: `standalone: true` + `trust_env: true`** — profil
    sekunder wajib standalone; trust_env wajib true agar adapter
    Telegram menghormati proxy egress. Restart gateway men-drop pesan
    in-flight → restart hanya saat idle; `keep.sh` meng-update env proxy
    diam-diam tanpa restart.
11. **Health alert = transisi, bukan polling** — `health-alert.sh`
    mengirim Telegram hanya saat status berubah (dedup via
    `health-alert.state`); tanpa token bot, alert dilewatkan diam-diam.
    Logika = versi produksi yang terbukti; hanya mengecek unit yang
    terpasang (opt-in aware), port di-render dari `config.sh`.

---

## 8. Pengujian & Validasi

| Uji | Hasil |
|---|---|
| `bash -n` semua skrip shell, `py_compile` semua python | lolos (v1.0 & v2.0) |
| Render template unit → `systemd-analyze verify` | bersih, tanpa sisa placeholder (v1.0) |
| `register-providers.py` vs salinan DB produksi (2x run) | idempoten; **menemukan bug**: `kv` butuh `scope NOT NULL` → diperbaiki (`scope='customModels'`) |
| `register-providers.py` vs DB fresh kosong | semua node/connection/model terbuat benar |
| `npm install --prefix` 9router@0.5.95 di sandbox | 12 dtk; `cli.js` ada & `node --check` lolos |
| Smoke test shim template (`BRIDGE_SHIM_PORT=20502`) | `/v1/models` → `{"id":"agent"}` |
| Render v2.0 (11 fase) + `install.sh --help` + `bash -n` | lolos (2026-10-03, smoke test ekstrak ke /tmp) |
| Render v2.1 (12 fase, +tailscaled.service, health-alert di-render) + `bash -n` semua skrip | lolos (2026-10-03 sore) |
| End-to-end di Muse target | **belum dilakukan** — butuh Muse kedua |

---

## 9. Operasi

- `systemctl status 9router muse-shim caveman headroom filebrowser tailscaled hermes-gateway` / `journalctl -u <unit> -f`
- `bash ~/workspace/systemd/keep.sh` — perbaikan manual / verifikasi
- Uji cepat: `bash ~/workspace/ask-9router.sh "halo"` lalu curl ke
  `<prefix>/agent` (lihat `README.md`)
- File sensitif: `~/workspace/9router-apikey.txt`, `~/workspace/filebrowser/.admin-pw`,
  `~/.hermes/profiles/telegram/.env` — jangan dishare / di-commit

## 10. Troubleshooting

Lihat tabel di `README.md` (401 → cek key; timeout 280 dtk → scheduled worker
belum aktif; port bentrok → `ss -ltnp`; unit hilang pasca VM reset → tunggu
cron keeper ≤5 menit).

## 11. Risiko & Batasan

1. **Belum teruji di Muse kedua** — risiko tertinggi; checklist kosong
   tersedia di `PORTABILITY.md` untuk mencatat temuan.
2. **Ketergantungan runtime target** — scheduled worker & cron keeper
   tidak bisa diotomatisasi; bila target tidak mendukungnya, bridge
   tidak jalan.
3. **Pollinations adalah layanan gratis pihak ketiga** — model/rate
   limit bisa berubah sewaktu-waktu tanpa pemberitahuan.
4. **RAM host** — lingkungan ini container tanpa limit cgroup yang
   terlihat; `free` menampilkan memori host (bukan jatah container).
5. **VM tetap bisa di-reset platform** — template tidak mengubah itu;
   yang dijamin hanya pemulihan otomatis.

## 12. Peta File

```
muse-stack-template/
├── README.md / PORTABILITY.md / config.sh / install.sh
├── docs/PRD-muse-stack-template.md   (dokumen ini)
├── 9router/{register-providers.py, ask-9router.sh, README.md}
├── muse-bridge/{shim.py, scheduled-worker-prompt.md, hook-poller.sh, worker-prompt.md, HOOK-SETUP.md}
├── caveman/{caveman.yaml, README.md}
├── headroom/{README.md}
├── filebrowser/{README.md}
├── hermes/{telegram-config.yaml, profile.yaml, .env.example, README.md}
├── systemd/{9router.service, muse-shim.service, caveman.service, caveman-run.sh,
│           headroom.service, filebrowser.service, tailscaled.service,
│           hermes-gateway.service, container-app@.service, keep.sh, health-alert.sh}
└── container/{enter.sh, README.md}
```

## 13. Pertanyaan Terbuka

- [ ] Hasil uji instalasi di Muse kedua (akun/email berbeda)
- [ ] Apakah 9router meng-cache `apiKeys` di memori (saat ini diatasi
      dengan restart bila key baru dibuat — perlu konfirmasi)
- [ ] Perilaku di arsitektur non-x86_64 / distro non-Ubuntu
- [ ] Instalasi caveman otomatis dari nol (unduh biner via `caveman start`
      sekali) belum diuji di mesin kedua — fallback manual ada di `caveman/README.md`
- [ ] Flag CLI filebrowser v2.63.23 dipakai di installer; versi lain
      mungkin berbeda flag
