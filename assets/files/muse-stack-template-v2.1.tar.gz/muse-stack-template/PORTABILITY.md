# PORTABILITY.md — bisakah ini dipasang di Muse lain? (penilaian jujur)

Jawaban singkat: **ya, bisa**, dengan langkah manual. Yang di bawah ini
hasil bedah komponen per komponen dari instalasi yang sudah teruji
(snapshot 2026-10-01, disinkronkan ulang dengan kondisi produksi 2026-10-03
sore: worker terjadwal 30 dtk, tailscaled, health-alert versi produksi).

## Riwayat sinkronisasi

- **2026-10-01**: template awal dari instalasi yang lolos uji end-to-end.
- **2026-10-03 (sore)**: sinkronisasi besar — `health-alert.sh` diganti ke
  versi produksi yang terbukti mengirim alert down/pulih (bukan versi generik
  yang belum teruji); `keep.sh` dapat blok `tailscaled.env` + komentar
  timezone yang lebih akurat; unit `tailscaled.service` baru;
  `INSTALL_TAILSCALE` di `config.sh`/`install.sh`; `hermes/.env.example`
  dibersihkan; worker utama didokumentasikan sebagai scheduled worker
  30 detik (hook jadi cadangan).

## Yang 100% portabel (file biasa, ikut template)

- `muse-bridge/shim.py` — server HTTP Python murni, tanpa dependensi
  eksternal. Port bisa dikonfigurasi via env `BRIDGE_SHIM_PORT`.
- `systemd/*.service` — template dengan placeholder `{{HOME}}`,
  `{{NODE}}`, `{{PYTHON}}`, `{{NINEROUTER_PORT}}`, `{{SHIM_PORT}}`,
  `{{BRIDGE_PREFIX}}`, `{{CAVEMAN_PORT}}`, `{{HEADROOM_PORT}}`,
  `{{FILEBROWSER_PORT}}`; di-render `install.sh`.
- `systemd/keep.sh` — hanya pakai `$HOME`, `systemctl`, `cmp`;
  generik: unit baru di `~/workspace/systemd/` otomatis ikut dikelola;
  menulis `hermes-gateway.env` + `tailscaled.env` bila `https_proxy` ada.
- `systemd/health-alert.sh` — logika produksi (terbukti mengirim alert
  down/pulih 2026-10-02 s.d. 2026-10-03); port di-render `install.sh`
  dari `config.sh`; hanya mengecek unit yang terpasang (opt-in aware).
  Diam (tanpa alert) bila token bot Telegram tidak dikonfigurasi.
  Bisa dioverride via env `HEALTH_ALERT_ENV`.
- `systemd/caveman-run.sh` — wrapper: `exec` biner foreground.
- `muse-bridge/hook-poller.sh` — hanya pakai `$HOME`.
- `container/enter.sh` — hanya pakai `$HOME`.
- `9router/register-providers.py` — SQL langsung ke
  `~/.9router/db/data.sqlite`; UUID di-generate fresh per instalasi,
  idempoten.
- `9router/ask-9router.sh` — baca key dari file lokal.
- `caveman/caveman.yaml`, `hermes/telegram-config.yaml`,
  `hermes/profile.yaml`, `hermes/.env.example` — template dengan
  placeholder, tanpa nilai rahasia.

## Yang perlu adaptasi di mesin target

| Butuh | Kenapa | Solusi di template |
|---|---|---|
| Linux + systemd (PID 1) + root | Unit + `/etc/systemd/system` | Dicek di awal `install.sh` |
| `node`, `npm`, `python3`, `sqlite3`, `curl`, `jq` | Dependensi | Dicek di awal `install.sh`; gagal dengan pesan jelas |
| Path `node`/`python3` | Beda distro, beda path | Di-resolve saat install (`command -v`), bukan hardcode |
| Path 9router `cli.js` | Cache npx pakai hash acak per mesin | Installer pakai `npm install --prefix ~/workspace/9router-app` → path deterministik |
| Port bentrok | Mesin target mungkin memakai port itu | Bisa diubah di `config.sh` sebelum install |
| Prefix `kamu` | Bebas, tapi JANGAN `muse` (tabrakan provider built-in 9router) | Bisa diubah di `config.sh` |
| `pip install` headroom | pip system ditolak PEP 668 di Debian | Installer pakai venv `~/workspace/headroom-venv` |
| Biner caveman | `npm i -g` hilang saat VM diganti | Installer mengunduh biner standalone sekali ke `~/.caveman/bin/` (durable); unit tidak bergantung pada CLI |
| Biner filebrowser | `/usr/local/bin` hilang saat VM diganti | Installer mengunduh ke `~/workspace/filebrowser/bin/` (durable) |
| Biner tailscaled | Perlu biner statik tailscale | Installer mengunduh static build linux-amd64 dari `pkgs.tailscale.com/stable/` ke `~/workspace/tailscale/` (durable) |
| Login Tailscale | Identity-bound (akun user) | Manual: `~/workspace/tailscale/tailscale up` lalu login di browser |
| Proxy egress | Mesin target mungkin tidak butuh proxy | `keep.sh` hanya menulis `hermes-gateway.env` bila `https_proxy` ada; unit tetap jalan tanpanya |
| Path CLI `hermes` | Bisa berbeda di mesin target | Komentar di `systemd/hermes-gateway.service`; sesuaikan `ExecStart` bila perlu |

## Yang TIDAK bisa diotomatisasi (langkah manual)

1. **Scheduled worker muse-bridge (tiap 30 detik)** — worker hidup di
   runtime Muse target, bukan di file. Buat scheduled task/cronjob dengan
   interval 30 detik (max_running=1, overlap=skip) dan tempel seluruh isi
   `muse-bridge/scheduled-worker-prompt.md` sebagai instruksinya
   (lihat `muse-bridge/HOOK-SETUP.md`). Hook `muse-bridge-queue`
   (poller + `worker-prompt.md`) tetap disediakan sebagai **cadangan**.
   Tanpa worker, request ke `kamu/agent` akan timeout setelah 280 detik.

2. **Cron keeper** (`bash ~/workspace/systemd/keep.sh` tiap 5 menit) —
   cron hidup di scheduler Muse target. Tanpa ini, VM reset tidak
   pulih otomatis.

3. **Kredensial** — tidak ada kredensial yang ikut template. API key
   9router & password admin filebrowser di-generate fresh oleh installer;
   **token bot Telegram + allowlist ID harus dari tangan pengguna**
   (lihat `hermes/README.md`). (Jalur Meta Model API memang tidak
   diikutkan: masih terblokir di lingkungan ini.)

4. **Headroom di dashboard 9router** — Endpoint → Token Saver → Headroom
   → `http://localhost:8787`. Klik manual di UI; tidak ada API untuk ini.

5. **Node 9router yang sudah terdaftar tidak diubah installer** —
   `register-providers.py` idempoten (melewati prefix yang ada). Migrasi
   baseUrl (mis. mengarahkan `pllns` lewat caveman) dilakukan manual di
   dashboard atau dengan menghapus node lalu menjalankan ulang installer.

## Yang BERBEDA hasilnya di Muse lain (by design)

- **Bridge menjawab sebagai Muse target**, bukan sebagai Muse asal.
  Worker membaca `MEMORY.md` milik Muse target → kepribadian, memori,
  dan pengetahuan = milik akun target. Itu memang tujuannya: tiap
  Muse punya "kamu/agent"-nya sendiri.
- **Email akun tidak relevan.** Tidak ada satu pun komponen yang
  terikat ke email — yang terikat hanya kapabilitas runtime
  (hooks, cron, shell, systemd).
- **Health alert butuh bot Telegram target sendiri.** Tanpa
  `TELEGRAM_BOT_TOKEN` + `TELEGRAM_ALLOWED_USERS`, alert dilewatkan
  diam-diam — stack tetap jalan, hanya tanpa notifikasi.
- **`USE_CAVEMAN` / `INSTALL_*` adalah pilihan instalasi**, tercatat di
  `config.sh` — bukan hardcode. Kombinasi yang teruji di asal:
  caveman=1, headroom=1, filebrowser=1, tailscale=1, hermes-gateway=1 (opt-in),
  container=1.

## Yang belum teruji

Template ini disalin dari instalasi yang lolos uji end-to-end
(HTTP 200, `kamu/agent` menjawab benar, kill-test systemd, simulasi
hapus unit, VM reset sungguhan 2026-10-02 & 2026-10-03 pulih via keeper).
**Instalasi di Muse kedua belum pernah dicoba** — kalau kamu mencobanya
dan menemukan yang gagal, catat di sini:

- [ ] (tulis temuanmu)

Catatan jujur tambahan:
- Instalasi caveman otomatis (unduh biner via `caveman start` sekali)
  mengikuti persis yang terjadi di mesin asal, tapi belum diuji dari
  nol di mesin lain — bila gagal, `caveman/README.md` berisi langkah manual.
- Instalasi tailscale otomatis (unduh static build dari pkgs.tailscale.com)
  belum diuji dari nol di mesin lain; URL mengikuti pola
  `tailscale_<versi>_linux_amd64.tgz` yang stabil selama bertahun-tahun,
  tapi bila pola berubah, sesuaikan `install.sh` langkah tailscale.
- `filebrowser config init` / `users add` mengikuti CLI v2.63.23;
  flag bisa berbeda di versi lain.
- Arsitektur selain x86_64 belum diuji (biner caveman, filebrowser, &
  tailscale yang diunduh adalah build linux-amd64).
