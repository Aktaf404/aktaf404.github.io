# Headroom — Token Saver proxy (context optimizer untuk 9router)

Headroom (`headroom-ai[proxy]`) adalah proxy penghemat token/konteks yang
duduk di depan 9router sebagai **Token Saver**. Di instalasi asal
(2026-10-02) ia berjalan di `127.0.0.1:8787` sebagai unit systemd
`headroom.service` (`Restart=always`, keeper-managed).

## Cara pasang (dilakukan install.sh)

```bash
python3 -m venv ~/workspace/headroom-venv
~/workspace/headroom-venv/bin/pip install "headroom-ai[proxy]==0.39.1"
# unit menjalankan: headroom-venv/bin/headroom proxy --port 8787
```

**Pelajaran penting:** `pip install` langsung ke system **GAGAL** di
lingkungan Debian — paket `typing_extensions` milik distro (RECORD hilang,
PEP 668 menolak instalasi system-wide). Solusinya: venv terpisah di
`~/workspace/headroom-venv/`, unit systemd menunjuk ke biner di dalam venv.
(Versi di `config.sh`: `HEADROOM_VERSION`.)

## Langkah MANUAL (tidak bisa diotomatisasi)

Aktifkan di dashboard 9router: **Endpoint → Token Saver → Headroom**,
arahkan ke `http://localhost:8787`. Tanpa langkah ini, headroom berjalan
tapi tidak dipakai 9router.

## Verifikasi

```bash
systemctl is-active headroom
curl -s --noproxy '*' http://127.0.0.1:8787/health   # 200 (aggregate "unhealthy"
# hanya berarti cek upstream default anthropic.com gagal — tidak dipakai di setup ini)
```

Catatan: `/health` mengembalikan status agregat yang mencakup cek upstream
default (`anthropic.com`). Selama dipakai sebagai Token Saver 9router,
status agregat itu tidak relevan.
