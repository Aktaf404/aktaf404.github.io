#!/usr/bin/env python3
"""register-providers.py — daftarkan provider Pollinations + Muse Bridge ke 9router.

Idempoten: baris yang sudah ada dilewati (dicek lewat prefix di data JSON).
Baca konfigurasi dari environment:
  NINEROUTER_DB, SHIM_PORT,
  BRIDGE_PREFIX, BRIDGE_NAME,
  POLL_PREFIX, POLL_NAME, POLL_BASE_URL, POLL_MODELS
Mekanisme yang dipakai sama persis dengan instalasi yang sudah teruji:
  providerNodes / providerConnections  -> node + koneksi (prefix routing)
  kv  key "{prefix}|{model}|llm"       -> registrasi model custom
"""
import json, os, sqlite3, sys, uuid

DB = os.environ["NINEROUTER_DB"]
SHIM_PORT = os.environ["SHIM_PORT"]
BRIDGE_PREFIX = os.environ["BRIDGE_PREFIX"]
BRIDGE_NAME = os.environ["BRIDGE_NAME"]
POLL_PREFIX = os.environ["POLL_PREFIX"]
POLL_NAME = os.environ["POLL_NAME"]
POLL_BASE_URL = os.environ["POLL_BASE_URL"]
POLL_MODELS = [m.strip() for m in os.environ.get("POLL_MODELS", "").split(",") if m.strip()]

def ensure_node(cur, prefix, name, base_url):
    row = cur.execute(
        "SELECT id FROM providerNodes WHERE json_extract(data,'$.prefix') = ?",
        (prefix,),
    ).fetchone()
    if row:
        print(f"  node {prefix}: sudah ada ({row[0]}), dilewati")
        return row[0]
    node_id = f"openai-compatible-chat-{uuid.uuid4()}"
    node_data = {"prefix": prefix, "apiType": "chat", "baseUrl": base_url}
    cur.execute(
        "INSERT INTO providerNodes (id, type, name, data) VALUES (?,?,?,?)",
        (node_id, "openai-compatible", name, json.dumps(node_data)),
    )
    print(f"  node {prefix}: dibuat ({node_id})")
    return node_id

def ensure_connection(cur, node_id, prefix, name, base_url):
    row = cur.execute(
        "SELECT id FROM providerConnections WHERE provider = ?", (node_id,)
    ).fetchone()
    if row:
        print(f"  connection {prefix}: sudah ada ({row[0]}), dilewati")
        return
    conn_id = str(uuid.uuid4())
    conn_data = {
        "apiKey": "not-needed",          # Pollinations keyless, shim lokal tanpa auth
        "testStatus": "unknown",
        "providerSpecificData": {
            "prefix": prefix, "apiType": "chat", "baseUrl": base_url,
            "nodeName": name, "connectionProxyEnabled": False,
            "connectionProxyUrl": "", "connectionNoProxy": "",
        },
    }
    cur.execute(
        "INSERT INTO providerConnections (id, provider, authType, name, priority, isActive, data)"
        " VALUES (?,?,?,?,1,1,?)",
        (conn_id, node_id, "apikey", name, json.dumps(conn_data)),
    )
    print(f"  connection {prefix}: dibuat ({conn_id})")

def ensure_kv_model(cur, prefix, model, display_name):
    key = f"{prefix}|{model}|llm"
    if cur.execute("SELECT 1 FROM kv WHERE scope = 'customModels' AND key = ?", (key,)).fetchone():
        print(f"  model {prefix}/{model}: sudah terdaftar, dilewati")
        return
    value = json.dumps({
        "providerAlias": prefix, "id": model, "type": "llm", "name": display_name,
    })
    cur.execute("INSERT INTO kv (scope, key, value) VALUES ('customModels',?,?)", (key, value))
    print(f"  model {prefix}/{model}: didaftarkan")

def main():
    if not os.path.isfile(DB):
        print(f"DB 9router belum ada: {DB}\nJalankan dulu keep.sh agar 9router membuat DB-nya.",
              file=sys.stderr)
        sys.exit(1)

    con = sqlite3.connect(DB)
    cur = con.cursor()

    print(f"[provider] {BRIDGE_NAME} ({BRIDGE_PREFIX})")
    node_id = ensure_node(cur, BRIDGE_PREFIX, BRIDGE_NAME,
                          f"http://127.0.0.1:{SHIM_PORT}/v1")
    ensure_connection(cur, node_id, BRIDGE_PREFIX, BRIDGE_NAME,
                      f"http://127.0.0.1:{SHIM_PORT}/v1")
    # Model bridge: TIDAK perlu entri kv. Client meminta "<prefix>/agent",
    # 9router mem-strip prefix lalu mem-forward model "agent" ke shim.
    # (Instalasi teruji berjalan tanpa baris kv untuk bridge.)

    print(f"[provider] {POLL_NAME} ({POLL_PREFIX})")
    node_id = ensure_node(cur, POLL_PREFIX, POLL_NAME, POLL_BASE_URL)
    ensure_connection(cur, node_id, POLL_PREFIX, POLL_NAME, POLL_BASE_URL)
    for m in POLL_MODELS:
        ensure_kv_model(cur, POLL_PREFIX, m, f"{POLL_NAME} {m}")

    con.commit()
    con.close()
    print("OK: provider terdaftar.")

if __name__ == "__main__":
    main()
