#!/bin/bash
# ask-9router.sh — jembatan: kirim prompt ke model 9router (gratis via Pollinations), cetak jawabannya.
# Pakai:  bash ~/workspace/ask-9router.sh "pertanyaanmu"
# atau:   echo "teks panjang" | bash ~/workspace/ask-9router.sh
# Model bisa diganti: MODEL=pllns/openai-fast bash ~/workspace/ask-9router.sh "halo"
set -u
MODEL="${MODEL:-pllns/gpt-oss}"
if [ $# -gt 0 ]; then PROMPT="$1"; else PROMPT="$(cat)"; fi
[ -z "${PROMPT:-}" ] && { echo "kasih prompt dulu"; exit 1; }

KEY=""
[ -f "$HOME/workspace/9router-apikey.txt" ] && KEY="$(cat "$HOME/workspace/9router-apikey.txt")"

AUTH=()
[ -n "$KEY" ] && AUTH=(-H "Authorization: Bearer $KEY")

BODY="$(jq -n --arg m "$MODEL" --arg p "$PROMPT" '{model:$m, messages:[{role:"user", content:$p}]}' 2>/dev/null)"
if [ -z "$BODY" ]; then
  echo "butuh jq, tidak ketemu"
  exit 1
fi

RESP="$(curl -s -m 90 http://localhost:20128/v1/chat/completions \
  -H "Content-Type: application/json" "${AUTH[@]}" -d "$BODY")"

OUT="$(echo "$RESP" | jq -r '.choices[0].message.content // empty' 2>/dev/null)"
if [ -z "$OUT" ]; then
  echo "$RESP" | head -c 500
  echo
  exit 1
fi
echo "$OUT"
