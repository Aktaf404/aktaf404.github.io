# 9router/README.md

Direktori ini berisi skrip pendukung 9router untuk template:

- `register-providers.py` — dipanggil otomatis oleh `install.sh`.
  Mendaftarkan ke DB 9router (`~/.9router/db/data.sqlite`):
  - node + connection **Muse Bridge** (prefix dari `config.sh`, mis. `kamu`)
  - node + connection **Pollinations** (prefix `pllns`, keyless)
  - model custom `pllns/gpt-oss`, `pllns/openai-fast` via tabel `kv`
    (key `{prefix}|{model}|llm`).
  Idempoten: aman dijalankan ulang.
- `ask-9router.sh` — helper shell: kirim prompt ke model 9router,
  baca API key dari `~/workspace/9router-apikey.txt`.
  ```bash
  bash ~/workspace/ask-9router.sh "pertanyaanmu"
  MODEL=pllns/openai-fast bash ~/workspace/ask-9router.sh "halo"
  ```

Catatan: model bridge `<prefix>/agent` TIDAK butuh entri `kv` —
9router mem-strip prefix lalu mem-forward model `agent` ke shim.
