# muse-stack-template

Paket portabel berisi **seluruh stack yang sudah teruji jalan**:

| Komponen | Fungsi |
|---|---|
| **9router** (v0.5.95) | Gateway model AI lokal di `http://localhost:20128`, auto-restart via systemd |
| **muse-bridge** | Shim OpenAI-compatible → antrean → worker agent Muse. Model publik: `kamu/agent` |
| **Pollinations** | Provider gratis (keyless) di 9router: `pllns/gpt-oss`, `pllns/openai-fast` |
| **caveman** | Token-saver proxy — upstream optimizer: `9router → caveman:8788 → Pollinations` |
| **headroom** | Token Saver proxy (`headroom-ai[proxy]`) di `:8787` — context optimizer 9router |
| **filebrowser** | File manager web ringan di `:8090` (single binary, scope `/home/hatch`) |
| **tailscale** | VPN privat (userspace networking) — akses mesin dari mana saja |
| **hermes** (opt-in) | Telegram gateway → bot menjawab sebagai Muse target via `kamu/agent` |
| **health-alert** | Alert Telegram saat service down/pulih (dedup, satu pesan per kejadian) |
| **systemd units** | Unit + `keep.sh` keeper + template `container-app@.service` |
| **linux-big-disk** | Container Ubuntu 24.04 minimal (~80 MB, chroot) |

Hasil akhir di Muse target: `hermes --model kamu/agent "pertanyaan"` dijawab
oleh **Muse target itu sendiri** (memori & kepribadiannya), lewat 9router.

```
Hermes/client --HTTP--> 9router:20128 --HTTP--> shim:20501
     shim tulis queue/<id>.json, long-poll (maks 280 dtk)
     scheduled worker (cron 30 dtk, jalur utama) jawab & tulis responses/<id>.json
     hook poller (tiap 10 dtk, cadangan) — aman jalan bareng, skip duplikat
     worker jawab sebagai Muse target, tulis {"content": "..."}
     shim baca response --> 9router --> client

pllns/* : 9router:20128 --HTTP--> caveman:8788 --HTTP--> text.pollinations.ai
     (kamu/agent SENGAJA tidak lewat caveman — langsung ke shim)

systemd: 9router, muse-shim, caveman, headroom, filebrowser, tailscaled
         (+ hermes-gateway bila opt-in)
cron (tiap 5 mnt): bash ~/workspace/systemd/keep.sh
   -> pasang ulang unit yang hilang/berubah, enable, pastikan aktif,
      update env proxy (hermes-gateway.env, tailscaled.env), lalu
      health-alert.sh cek unit+port & alert Telegram bila ada transisi down/pulih
```

## Syarat

- Linux dengan **systemd sebagai PID 1** + akses **root**
- `python3`, `sqlite3`, `node`, `npm`, `curl`, `jq`
- Koneksi internet (unduh 9router, ubuntu-base ±30 MB, biner caveman/filebrowser)
- Runtime Muse target punya: **hooks** (poller + worker) dan **cron/scheduler**

Lihat `PORTABILITY.md` untuk penilaian jujur apa yang bisa/tidak bisa
dipindahkan ke Muse lain.

## Cara pasang

```bash
# 1. (opsional) sesuaikan dulu
cp config.sh config.local.sh   # edit port/prefix/komponen bila perlu; config.sh biarkan apa adanya
nano config.local.sh

# 2. jalankan installer (butuh root; otomatis sudo bila perlu)
bash install.sh
# bantuan: bash install.sh --help
```

Installer itu **idempoten** — aman dijalankan ulang kapan saja.
Komponen opsional dikontrol di `config.sh`: `INSTALL_CAVEMAN`,
`INSTALL_HEADROOM`, `INSTALL_FILEBROWSER`, `INSTALL_TAILSCALE`,
`INSTALL_HERMES_GATEWAY` (opt-in, default 0), `INSTALL_CONTAINER`.

## Setelah install.sh (langkah manual)

### 1. Scheduled worker muse-bridge (tiap 30 detik)
Ikuti **`muse-bridge/HOOK-SETUP.md`** — buat scheduled task/cronjob di
runtime Muse target (interval 30 dtk, max_running=1, overlap=skip) dan
tempel seluruh isi `muse-bridge/scheduled-worker-prompt.md` sebagai
instruksinya. Ini jalur utama sejak 2026-10-03 (menggantikan hook sebagai
jalur utama — hook `muse-bridge-queue` tetap bisa dipasang sebagai cadangan,
aman jalan bareng karena keduanya skip request yang sudah ada
`responses/<id>.json`-nya).

### 2. Cron keeper (auto-restart pasca VM reset)
`/etc/systemd/system` hilang saat VM diganti, jadi butuh keeper.
Buat cron di Muse target, tiap 5 menit:
```bash
bash ~/workspace/systemd/keep.sh
```
`keep.sh` memasang ulang unit yang hilang/berubah, me-reload systemd,
memastikan semua service aktif, meng-update env proxy, lalu menjalankan
`health-alert.sh` (alert Telegram hanya saat ada transisi down/pulih —
perlu bot Telegram dari langkah 5, kalau tidak ada alert dilewatkan diam-diam).
Crash biasa ditangani langsung oleh systemd (`Restart=always`, pulih dalam hitungan detik).

### 3. Headroom di dashboard 9router (bila INSTALL_HEADROOM=1)
Aktifkan manual: **Endpoint → Token Saver → Headroom** → `http://localhost:8787`.
Tanpa ini headroom berjalan tapi tidak dipakai. Lihat `headroom/README.md`.

### 4. Hermes (opsional)
```bash
hermes config set providers.custom.base_url http://localhost:20128/v1
# lalu pakai model bridge:
hermes --model kamu/agent "halo"
# (ganti kamu/ dengan BRIDGE_PREFIX bila diubah)
```

### 5. Telegram gateway (opt-in, bila INSTALL_HERMES_GATEWAY=1)
Ikuti **`hermes/README.md`** — butuh bot token dari [@BotFather](https://t.me/BotFather)
dan ID numerik Telegram-mu untuk allowlist. **Tidak ada kredensial yang ikut
template** — token & allowlist diisi manual ke `~/.hermes/profiles/telegram/.env`.

### 6. Tailscale (bila INSTALL_TAILSCALE=1)
Daftarkan mesin ke tailnet-mu (identity-bound, tidak bisa diotomatisasi):
```bash
~/workspace/tailscale/tailscale up
```
lalu login di browser. Tanpa ini daemon jalan tapi tidak terhubung ke mana pun.

## Uji end-to-end

```bash
# 1. service hidup?
systemctl is-active 9router muse-shim caveman headroom filebrowser tailscaled

# 2. provider gratis (tanpa hook, langsung ke Pollinations via caveman)
bash ~/workspace/ask-9router.sh "jawab singkat: halo"

# 3. bridge ke Muse (butuh scheduled worker aktif!)
curl -s http://localhost:20128/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $(cat ~/workspace/9router-apikey.txt)" \
  -d '{"model":"kamu/agent","messages":[{"role":"user","content":"jawab singkat: siapa kamu?"}]}'
```

Tes #3 butuh waktu detik–menit (satu worker run per request) dan
mengembalikan HTTP 200 dengan `choices[0].message.content`.

## Struktur

```
muse-stack-template/
├── README.md                 # kamu di sini
├── PORTABILITY.md            # apa yang portabel & apa yang tidak
├── config.sh / install.sh    # konfigurasi + installer
├── 9router/
│   ├── register-providers.py # daftar node/koneksi/model ke DB 9router
│   ├── ask-9router.sh        # helper tanya model gratis dari shell
│   └── README.md
├── muse-bridge/
│   ├── shim.py               # server OpenAI-compatible (port via BRIDGE_SHIM_PORT)
│   ├── scheduled-worker-prompt.md # instruksi scheduled worker 30 dtk (JALUR UTAMA)
│   ├── hook-poller.sh        # skrip hook cadangan (disalin ke ~/hooks/scripts/)
│   ├── worker-prompt.md      # instruksi worker hook cadangan
│   └── HOOK-SETUP.md         # panduan pasang scheduled worker + hook cadangan
├── caveman/
│   ├── caveman.yaml          # config proxy (mode compress, upstream Pollinations)
│   └── README.md             # pelajaran daemonize + npm-ephemeral
├── headroom/
│   └── README.md             # venv caveat (PEP 668) + langkah dashboard manual
├── filebrowser/
│   └── README.md             # lokasi durable + prosedur ganti scope/port
├── hermes/
│   ├── telegram-config.yaml  # override config profil telegram (placeholder)
│   ├── profile.yaml          # deskripsi profil
│   ├── .env.example          # format kredensial (TIDAK ikut nilai asli)
│   └── README.md             # panduan pasang Telegram gateway
├── systemd/
│   ├── 9router.service       # template unit (placeholder {{...}})
│   ├── muse-shim.service     # template unit
│   ├── caveman.service       # template unit (+ caveman-run.sh wrapper)
│   ├── caveman-run.sh        # wrapper: exec biner foreground
│   ├── headroom.service      # template unit
│   ├── filebrowser.service   # template unit
│   ├── tailscaled.service    # template unit (VPN userspace)
│   ├── hermes-gateway.service# template unit (opt-in)
│   ├── container-app@.service# template aplikasi dalam container
│   ├── keep.sh               # keeper: unit + env proxy + health-alert
│   └── health-alert.sh       # cek service + alert Telegram (dedup)
└── container/
    ├── enter.sh              # masuk ke container
    └── README.md
```

## Troubleshooting

| Gejala | Cek |
|---|---|
| `kamu/agent` 401 | API key: `cat ~/workspace/9router-apikey.txt`, header `Authorization: Bearer ...` |
| `kamu/agent` timeout 280 dtk | Scheduled worker belum terdaftar / tidak jalan → `muse-bridge/HOOK-SETUP.md` |
| Port bentrok | `ss -ltnp`, matikan proses lama, `systemctl restart <service>`; port di `config.sh` |
| Unit hilang setelah VM reset | Normal — cron keeper memasang ulang ≤5 menit |
| Model `pllns/...` tidak ada | `register-providers.py` belum jalan / upstream Pollinations berubah |
| Prefix `muse` gagal routing | JANGAN pakai prefix `muse` — tabrakan dengan provider built-in 9router |
| `caveman` restart-loop | Jangan jalankan `caveman start` di bawah systemd — unit memakai `caveman-run.sh` (foreground) |
| `headroom` pip gagal | Wajib venv (`~/workspace/headroom-venv`) — pip system ditolak PEP 668 |
| `filebrowser` exit 203/EXEC | Biner harus di `~/workspace/filebrowser/bin/` (durable), bukan `/usr/local/bin` |
| Alert Telegram tidak terkirim | `health-alert.sh` butuh `TELEGRAM_BOT_TOKEN` + `TELEGRAM_ALLOWED_USERS` di `~/.hermes/profiles/telegram/.env`; tanpa itu alert dilewatkan diam-diam |
| `pllns/*` tidak lewat caveman | `USE_CAVEMAN=1` hanya berlaku saat node didaftarkan; node lama: ubah baseUrl di dashboard atau hapus node + rerun installer |

## Keamanan

- `~/workspace/9router-apikey.txt` = kredensial lokal. Jangan dishare,
  jangan commit ke repo publik.
- `~/.hermes/profiles/telegram/.env` (token bot + allowlist ID) dan
  `~/workspace/filebrowser/.admin-pw` = rahasia lokal (mode 600).
- Template ini tidak membawa kredensial apa pun — installer men-generate
  API key 9router & password admin filebrowser baru per instalasi;
  token Telegram selalu dari tangan pengguna.
