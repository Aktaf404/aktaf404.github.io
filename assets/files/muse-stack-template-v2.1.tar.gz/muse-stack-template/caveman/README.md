# Caveman — token-saver proxy (upstream optimizer untuk 9router)

Caveman duduk **di antara 9router dan provider** sebagai proxy yang
mengompresi request (`mode: compress`): `pllns/*` (Pollinations) dirutekan
9router → caveman (`127.0.0.1:8788`) → `text.pollinations.ai`.

```
9router:20128 --HTTP--> caveman:8788 --HTTP--> text.pollinations.ai/openai
```

## Yang dipasang install.sh

1. **Biner standalone** `~/.caveman/bin/caveman-proxy` — biner Go, dijalankan
   **langsung di foreground** oleh systemd via `systemd/caveman-run.sh`.
   Lokasi `~/.caveman/` ada di home → **selamat dari VM reset** (tidak seperti
   `/usr/bin/caveman` dari `npm i -g`, yang hilang setiap VM diganti).
2. **Config** `~/.caveman/caveman.yaml` (dari `caveman/caveman.yaml` template;
   tidak ditimpa bila sudah ada).
3. **Unit** `caveman.service` (keeper-managed, `Restart=always`).

## Cara biner diperoleh (jujur, sesuai instalasi asal 2026-10-02)

1. `npm i -g @caveman-ai/cli` (atau versi pin di `config.sh`: `CAVEMAN_NPM`).
2. Jalankan `caveman start` **sekali** — CLI mengunduh biner standalone
   (Go) ke `~/.caveman/bin/` (bukti: `.bin-manifest.json`, release `bin-v2.0.0`).
3. `caveman start` **selalu daemonize** (spawn detached) — matikan lagi
   (`pkill -f caveman-proxy`); systemd menjalankan binernya langsung.

`install.sh` mengotomatisasi ketiga langkah ini dan melewatinya bila biner
sudah ada (idempoten). Bila langkah otomatis gagal, lakukan manual sesuai
di atas lalu jalankan ulang `install.sh`.

## Pelajaran penting

- **Jangan jalankan `caveman start` di bawah systemd** — proses daemonize
  membuat unit `Type=simple` masuk restart-loop tanpa henti.
- **Jangan arahkan upstream caveman ke 9router** — itu loop
  `9router → caveman → 9router`. Arah yang benar: `9router → caveman → provider`.
- **Node `kamu/agent` (muse-bridge) SENGAJA tidak lewat caveman** —
  dibiarkan langsung ke shim agar gateway Telegram yang sudah jalan tidak
  tersentuh. Kompresi caveman hanya berlaku untuk model `pllns/*`.
  (Diatur di `config.sh`: `USE_CAVEMAN=1` → `POLL_BASE_URL` =
  `http://127.0.0.1:8788/v1`. Untuk node yang sudah terdaftar, ganti
  baseUrl manual di dashboard 9router atau hapus node lalu jalankan ulang
  `register-providers.py`.)

## Verifikasi

```bash
systemctl is-active caveman
curl -s --noproxy '*' http://127.0.0.1:8788/ -o /dev/null -w '%{http_code}\n'  # 200/404 = hidup
bash ~/workspace/ask-9router.sh "jawab singkat: pong"   # 9router -> caveman -> Pollinations
```
