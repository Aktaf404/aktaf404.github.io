# container/README.md — container Linux ubuntu-base

Container minimal Ubuntu 24.04 di `~/workspace/linux-big-disk/rootfs`
(~80 MB, bukan VM penuh: chroot + unshare).

## Pakai

```bash
bash ~/workspace/linux-big-disk/enter.sh   # masuk sebagai root di dalam container
```

## Menjalankan aplikasi sebagai service

Template unit ada di `../systemd/container-app@.service`.
Contoh: web server python di dalam container sebagai service `myapp`:

```bash
cp ~/workspace/systemd/container-app@.service ~/workspace/systemd/myapp.service
# edit ~/workspace/systemd/myapp.service, ganti ExecStart jadi:
#   ExecStart=/usr/sbin/chroot /home/hatch/workspace/linux-big-disk/rootfs /usr/bin/python3 -m http.server 8080
#   (hapus %i)
bash ~/workspace/systemd/keep.sh
systemctl status myapp
```

`keep.sh` otomatis memasang ulang unit yang hilang/berubah setiap
dijalankan (dipanggil tiap 5 menit oleh cron keeper).
