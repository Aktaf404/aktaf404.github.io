#!/bin/bash
ROOTFS="$HOME/workspace/linux-big-disk/rootfs"
if [ ! -d "$ROOTFS/bin" ]; then
  echo "rootfs tidak ketemu di $ROOTFS"
  exit 1
fi
# pastikan DNS
echo "nameserver 8.8.8.8" > "$ROOTFS/etc/resolv.conf"
echo "nameserver 1.1.1.1" >> "$ROOTFS/etc/resolv.conf"
echo "Masuk ke Linux (Ubuntu 24.04) - disk 99GB..."
echo "Ketik 'exit' untuk keluar."
# coba mount proc/sys/dev kalau bisa, gagal pun lanjut
unshare --mount --pid --fork --mount-proc bash -c "
mount -t sysfs sysfs $ROOTFS/sys 2>/dev/null || true
mount --bind /dev $ROOTFS/dev 2>/dev/null || true
chroot $ROOTFS /bin/bash -c 'mount -t proc proc /proc 2>/dev/null || true; exec /bin/bash'
"
