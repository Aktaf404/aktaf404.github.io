#!/bin/bash
# health-alert.sh — cek kesehatan service + kirim alert Telegram saat ada yang down.
# Dijalankan di akhir keep.sh (cron runtime tiap 5 menit). Alert dikirim hanya
# saat terjadi transisi (down baru / baru pulih), bukan spam tiap 5 menit —
# status terakhir disimpan di health-alert.state (dedup: satu pesan per kejadian).
#
# Token bot dibaca dari file env (default: ~/.hermes/profiles/telegram/.env,
# bisa dioverride via env HEALTH_ALERT_ENV). Bila token/chat-id tidak ada,
# alert dilewatkan diam-diam — skrip tetap mencatat status ke keep.log.
# Secret (token) dibaca langsung dari file env, tidak pernah ditulis ke log.
#
# Daftar service yang dicek = unit yang TERPASANG di ~/workspace/systemd/
# (unit opt-in yang tidak di-install, mis. hermes-gateway, otomatis dilewati).
# Port di-render oleh install.sh dari config.sh (lihat placeholder di bawah).
# Logika ini disalin dari instalasi produksi yang sudah mengirim alert
# down/pulih beneran (2026-10-02 s.d. 2026-10-03).

SRC="$HOME/workspace/systemd"
ENV="${HEALTH_ALERT_ENV:-$HOME/.hermes/profiles/telegram/.env}"
STATE="$SRC/health-alert.state"
LOG="$SRC/keep.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] [health-alert] $1" >> "$LOG"; }

TOKEN="$(grep -E '^TELEGRAM_BOT_TOKEN=' "$ENV" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '[:space:]')"
CHAT="$(grep -E '^TELEGRAM_ALLOWED_USERS=' "$ENV" 2>/dev/null | tail -1 | cut -d= -f2- | cut -d, -f1 | tr -d '[:space:]')"

send_tg() {
  # $1 = teks pesan
  [ -n "$TOKEN" ] && [ -n "$CHAT" ] || { log "WARN: token/chat-id Telegram tidak ditemukan, alert dilewatkan"; return 1; }
  local resp
  resp=$(curl -s -m 20 -X POST "https://api.telegram.org/bot${TOKEN}/sendMessage" \
    -d "chat_id=${CHAT}" -d "parse_mode=HTML" \
    --data-urlencode "text=$1" 2>/dev/null)
  if echo "$resp" | grep -q '"ok":true'; then
    log "ALERT terkirim ke Telegram"
  else
    log "WARN: kirim Telegram gagal: $(echo "$resp" | head -c 200)"
  fi
}

# Cek: unit systemd + port yang hidup
declare -A DOWN=()
declare -A REASON=()

svc_down() { # $1=nama unit, $2=alasan
  DOWN["$1"]=1; REASON["$1"]="$2"
}

http_ok() { # $1=url
  curl -s --noproxy '*' -m 5 -o /dev/null -w "%{http_code}" "$1" 2>/dev/null | grep -qE '^(200|404)$'
}

port_url() { # $1 = nama unit -> echo URL atau string kosong
  case "$1" in
    9router)     echo "http://localhost:{{NINEROUTER_PORT}}/v1/models" ;;
    muse-shim)   echo "http://localhost:{{SHIM_PORT}}/" ;;
    headroom)    echo "http://localhost:{{HEADROOM_PORT}}/health" ;;
    # caveman: cukup port terbuka (dia tidak expose /v1/models)
    caveman)     echo "http://127.0.0.1:{{CAVEMAN_PORT}}/" ;;
    filebrowser) echo "http://127.0.0.1:{{FILEBROWSER_PORT}}/" ;;
    *)           echo "" ;;  # hermes-gateway, tailscaled: cek unit saja
  esac
}

units=()
for u in 9router muse-shim headroom caveman hermes-gateway tailscaled filebrowser; do
  [ -f "$SRC/$u.service" ] && units+=("$u")  # unit tidak di-install -> lewati
done

for u in "${units[@]}"; do
  systemctl is-active -q "$u" 2>/dev/null || { svc_down "$u" "unit tidak active ($(systemctl is-active "$u" 2>/dev/null))"; continue; }
  url="$(port_url "$u")"
  if [ -n "$url" ]; then
    http_ok "$url" || svc_down "$u" "port tidak respon ($url)"
  fi
done

# Status sekarang sebagai string terurut (untuk perbandingan transisi)
now=""
for u in "${units[@]}"; do
  if [ -n "${DOWN[$u]:-}" ]; then now+="$u=down;"; else now+="$u=up;"; fi
done

prev="$(cat "$STATE" 2>/dev/null)"
if [ "$now" != "$prev" ]; then
  if [ ${#DOWN[@]} -gt 0 ]; then
    msg="⚠️ <b>Service down</b> — $(date '+%d %b %H:%M') WIB\n"
    for u in "${!DOWN[@]}"; do msg+="• <code>$u</code>: ${REASON[$u]}\n"; done
    msg+="\nKeeper sudah coba restart otomatis. Kalau tetap down: <code>journalctl -u &lt;nama&gt;</code>"
    send_tg "$msg"
    log "DOWN: $(for u in "${!DOWN[@]}"; do echo -n "$u (${REASON[$u]}); "; done)"
  else
    [ -n "$prev" ] && { send_tg "✅ <b>Semua service pulih</b> — $(date '+%d %b %H:%M') WIB"; log "RECOVERED: semua service up"; }
  fi
  echo -n "$now" > "$STATE"
fi
exit 0
