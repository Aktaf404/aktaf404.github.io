#!/bin/bash
# caveman-run.sh — wrapper systemd untuk caveman proxy (:{{CAVEMAN_PORT}}).
#
# Menjalankan `caveman-proxy serve` LANGSUNG di foreground (biner Go di
# {{HOME}}/.caveman/bin/, baca {{HOME}}/.caveman/caveman.yaml yang menetapkan
# listen 127.0.0.1:{{CAVEMAN_PORT}}). systemd melacak proses asli; crash ->
# Restart=always bekerja sebagaimana mestinya. Tidak ada lagi ketergantungan
# pada CLI node /usr/bin/caveman (ephemeral: hilang setiap VM diganti).
set -u
exec {{HOME}}/.caveman/bin/caveman-proxy serve
