#!/bin/bash
# keep.sh — idempotent service keeper, dijalankan cron runtime tiap 5 menit.
#
# Kenapa keeper ini perlu: /etc/systemd/system itu EPHEMERAL — hilang setiap
# VM diganti. Unit-unit asli disimpan awet di ~/workspace/systemd/ (home
# persisten). Keeper ini memasang ulang unit yang hilang/berubah, enable,
# dan memastikan service-nya active. Crash di tengah jalan ditangani
# systemd sendiri via Restart=always (hitungan detik).
#
# Generik: unit baru cukup ditaruh sebagai ~/workspace/systemd/<nama>.service
# (file biasa, kecuali template *@.service) — keeper memasang, me-enable,
# dan memastikannya active; health-alert.sh otomatis ikut mengeceknya.
#
# Aman dijalankan berulang-ulang (tidak ngapa-ngapain bila semua sudah OK).

SRC="$HOME/workspace/systemd"
DEST="/etc/systemd/system"
LOG="$HOME/workspace/systemd/keep.log"

log() { echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG"; }

changed=0

# Zona waktu: pastikan Asia/Jakarta (WIB). /etc itu EPHEMERAL — setiap VM
# diganti, timezone balik ke UTC dan timestamp di log + pesan alert Telegram
# (yang dilabeli "WIB") jadi ngaco 7 jam. Idempoten: hanya disentuh bila
# zona aktif benar-benar bukan WIB (diukur dari `date +%Z`, bukan dari
# /etc/timezone yang kadang tidak bisa ditulis tanpa root — itu cuma label
# kosmetik, yang menentukan adalah /etc/localtime). Service yang sudah jalan
# sebelum perubahan perlu restart manual supaya cache tzdata-nya ikut
# ke-refresh (tidak dilakukan di sini agar keeper tidak me-restart service
# tiap 5 menit).
if [ "$(date +%Z)" != "WIB" ]; then
  ln -sf /usr/share/zoneinfo/Asia/Jakarta /etc/localtime 2>/dev/null || true
  echo "Asia/Jakarta" > /etc/timezone 2>/dev/null || true
  log "UPDATE: timezone di-set ke Asia/Jakarta (WIB)"
fi

# Proxy egress untuk unit yang butuh internet publik (hermes-gateway untuk
# Telegram, caveman untuk upstream Pollinations; systemd tidak mewarisi env).
# Di-generate dari env keeper tiap jalan.
# PENTING: file hanya di-update, service TIDAK di-restart otomatis saat
# isinya berubah — kredensial proxy bisa rotate tiap beberapa menit, dan
# restart berkala memicu "restart-loop breaker" (hermes) serta memutus
# polling/koneksi yang sedang jalan. Service yang crash di-restart systemd
# sendiri (Restart=always) dengan env file terbaru; itu jalur pemulihan
# yang benar.
ENVF="$SRC/hermes-gateway.env"
if [ -n "${https_proxy:-}" ]; then
  {
    echo "https_proxy=$https_proxy"
    echo "http_proxy=${http_proxy:-$https_proxy}"
    echo "HTTPS_PROXY=${HTTPS_PROXY:-$https_proxy}"
    echo "HTTP_PROXY=${HTTP_PROXY:-${http_proxy:-$https_proxy}}"
    echo "no_proxy=${no_proxy:-localhost,127.0.0.1}"
    echo "NO_PROXY=${NO_PROXY:-localhost,127.0.0.1}"
  } > "$ENVF.tmp" && chmod 600 "$ENVF.tmp"
  if ! cmp -s "$ENVF.tmp" "$ENVF" 2>/dev/null; then
    mv "$ENVF.tmp" "$ENVF"
    log "UPDATE: hermes-gateway.env (proxy berubah; dipakai saat start berikutnya)"
  else
    rm -f "$ENVF.tmp"
  fi
elif [ ! -f "$ENVF" ]; then
  log "WARN: https_proxy kosong dan $ENVF belum ada — unit ber-proxy butuh proxy untuk internet publik"
fi

# Proxy egress untuk tailscaled (control plane + DERP tailscale hanya
# terjangkau via proxy di lingkungan yang egress-nya diblokir; direct
# egress mungkin jalan di mesin target lain — blok ini aman di kedua kasus.
# Pola sama kayak di atas: file di-update diam-diam, tailscaled TIDAK
# di-restart saat proxy berubah — koneksi yang sudah jalan biasanya survive
# rotasi kredensial, dan crash di-restart systemd sendiri dengan env terbaru.)
TSENVF="$SRC/tailscaled.env"
if [ -n "${https_proxy:-}" ]; then
  {
    echo "https_proxy=$https_proxy"
    echo "http_proxy=${http_proxy:-$https_proxy}"
    echo "HTTPS_PROXY=${HTTPS_PROXY:-$https_proxy}"
    echo "HTTP_PROXY=${HTTP_PROXY:-${http_proxy:-$https_proxy}}"
    echo "no_proxy=${no_proxy:-localhost,127.0.0.1}"
    echo "NO_PROXY=${NO_PROXY:-localhost,127.0.0.1}"
  } > "$TSENVF.tmp" && chmod 600 "$TSENVF.tmp"
  if ! cmp -s "$TSENVF.tmp" "$TSENVF" 2>/dev/null; then
    mv "$TSENVF.tmp" "$TSENVF"
    log "UPDATE: tailscaled.env (proxy berubah; dipakai saat start berikutnya)"
  else
    rm -f "$TSENVF.tmp"
  fi
elif [ ! -f "$TSENVF" ]; then
  log "WARN: https_proxy kosong dan $TSENVF belum ada — tailscaled butuh proxy untuk control plane"
fi

for f in "$SRC"/*.service; do
  [ -e "$f" ] || continue
  name="$(basename "$f")"
  case "$name" in
    *@.service) continue ;;  # template: tidak di-install otomatis
  esac
  if ! cmp -s "$f" "$DEST/$name" 2>/dev/null; then
    cp "$f" "$DEST/$name"
    log "INSTALL/UPDATE: $name"
    changed=1
  fi
done
if [ "$changed" = 1 ]; then
  systemctl daemon-reload
  log "daemon-reload"
fi

for f in "$SRC"/*.service; do
  [ -e "$f" ] || continue
  name="$(basename "$f")"
  case "$name" in
    *@.service) continue ;;
  esac
  svc="${name%.service}"
  if ! systemctl is-enabled -q "$svc" 2>/dev/null; then
    systemctl enable "$svc" >/dev/null 2>&1 && log "ENABLE: $svc"
  fi
  if ! systemctl is-active -q "$svc" 2>/dev/null; then
    systemctl start "$svc" >/dev/null 2>&1
    if systemctl is-active -q "$svc" 2>/dev/null; then
      log "START: $svc"
    else
      log "FAILED: $svc tidak bisa start — cek 'journalctl -u $svc'"
    fi
  fi
done

# Sapu bersih supervisor shell lama bila masih nyangkut (sudah pensiun)
for pat in "9router-supervisor\.sh" "muse-bridge/supervisor\.sh"; do
  if pgrep -f "$pat" >/dev/null 2>&1; then
    pkill -f "$pat" 2>/dev/null
    log "CLEANUP: supervisor lama dimatikan ($pat)"
  fi
done
rm -f "$HOME/workspace/9router-supervisor.pid" "$HOME/workspace/muse-bridge/supervisor.pid"

# Health check + alert Telegram bila ada service yang down
# (dedup: satu pesan per kejadian; diam bila token bot tidak ada)
[ -x "$SRC/health-alert.sh" ] && "$SRC/health-alert.sh" >> "$LOG" 2>&1 || true

exit 0
