# FileBrowser — file manager web ringan

[FileBrowser](https://github.com/filebrowser/filebrowser) (single binary Go,
~36 MB, ~25 MB RAM) — UI mirip Drive untuk menjelajah disk VM dari browser.
Di instalasi asal (2026-10-03): v2.63.23, unit `filebrowser.service`
(`Restart=always`, keeper-managed), listen `127.0.0.1:8090`,
scope awal `/home/hatch/workspace` lalu diubah ke `/home/hatch` (~100 GB free).

## Cara pasang (dilakukan install.sh)

```bash
# 1. unduh ke lokasi DURABLE (bukan /usr/local/bin — lihat pelajaran di bawah)
curl -L -o /tmp/fb.tar.gz \
  https://github.com/filebrowser/filebrowser/releases/download/v2.63.23/linux-amd64-filebrowser.tar.gz
mkdir -p ~/workspace/filebrowser/bin
tar -xzf /tmp/fb.tar.gz -C ~/workspace/filebrowser/bin filebrowser

# 2. init DB + user admin (sekali saja; password di-generate installer)
cd ~/workspace/filebrowser
./bin/filebrowser config init
./bin/filebrowser users add admin <password-tergenerate> --perm.admin --scope /home/hatch
# password disimpan di ~/workspace/filebrowser/.admin-pw (mode 600)
```

(Versi di `config.sh`: `FILEBROWSER_VERSION`.)

**Pelajaran penting (2026-10-03):** biner awalnya dipasang di
`/usr/local/bin/filebrowser`. Saat VM diganti, `/usr/local` ikut ter-wipe
→ unit gagal start (`exit 203/EXEC`). Biner dipindah ke
`~/workspace/filebrowser/bin/` (home persisten) dan unit menunjuk ke sana —
reset berikutnya aman. **Jangan pasang biner di /usr/local** di lingkungan
ini.

## Mengubah scope / port (prosedur)

Service **HARUS di-stop dulu** — CLI FileBrowser timeout bila server sedang
memegang database:

```bash
systemctl stop filebrowser
cd ~/workspace/filebrowser
./bin/filebrowser users update admin --scope /direktori/baru
# atau: ./bin/filebrowser config set --port 8090 --address 127.0.0.1
systemctl start filebrowser
```

## Akses

Default hanya `127.0.0.1` (localhost). Akses remote butuh tunnel
(di instalasi asal: rencana via tunnel Cloudflare — di luar cakupan template).

## Verifikasi

```bash
systemctl is-active filebrowser
curl -s --noproxy '*' -o /dev/null -w '%{http_code}\n' http://127.0.0.1:8090/
```
