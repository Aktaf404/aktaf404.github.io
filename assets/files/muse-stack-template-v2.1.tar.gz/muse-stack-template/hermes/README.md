# Hermes — Telegram gateway (opt-in)

Menghubungkan bot Telegram ke stack ini: pesan Telegram → gateway hermes
→ 9router → model `{{BRIDGE_PREFIX}}/agent` (muse-bridge) → dijawab oleh
**Muse target itu sendiri** (memori & kepribadiannya).

> Komponen ini **opt-in**: `install.sh` melewatinya kecuali
> `INSTALL_HERMES_GATEWAY=1` di `config.sh`/`config.local.sh`, karena butuh
> (a) CLI `hermes` terinstal di mesin target, dan (b) bot token + allowlist
> dari tangan pengguna — tidak ada kredensial yang ikut template.

## Prasyarat

- CLI `hermes` terinstal (di luar cakupan template — ia bagian dari
  produk Muse; instalasi asal: `~/.local/bin/hermes`).
- Bot Telegram: buat via [@BotFather](https://t.me/BotFather) → dapatkan
  token. Cari tahu ID numerik Telegram-mu (mis. via [@userinfobot](https://t.me/userinfobot))
  untuk allowlist.

## Cara pasang

### Otomatis (bila INSTALL_HERMES_GATEWAY=1)

`install.sh` melakukan ini bila `hermes` ada di PATH:

1. `~/.hermes/profiles/telegram/config.yaml` ← dari `hermes/telegram-config.yaml`
   (placeholder di-render; **tidak menimpa** bila sudah ada).
2. `~/.hermes/profiles/telegram/profile.yaml` ← dari `hermes/profile.yaml`.
3. Unit `hermes-gateway.service` di-render ke `~/workspace/systemd/`
   (keeper memasang + menjalankannya).

### Manual (atau bila otomatis dilewati)

```bash
# 1. salin config (jangan timpa yang sudah ada)
mkdir -p ~/.hermes/profiles/telegram
cp hermes/telegram-config.yaml ~/.hermes/profiles/telegram/config.yaml   # edit placeholder
cp hermes/profile.yaml ~/.hermes/profiles/telegram/config.yaml           # (opsional)

# 2. isi kredensial — JANGAN taruh nilai asli di template/repo
cp hermes/.env.example ~/.hermes/profiles/telegram/.env
chmod 600 ~/.hermes/profiles/telegram/.env
nano ~/.hermes/profiles/telegram/.env   # isi TELEGRAM_BOT_TOKEN & TELEGRAM_ALLOWED_USERS

# 3. tes manual dulu
hermes -p telegram gateway run
# kirim pesan ke bot → harus dijawab sebagai Muse target
```

## Kunci konfigurasi (kenapa begitu)

| Kunci | Nilai | Kenapa |
|---|---|---|
| `model.default` | `<prefix>/agent` | Bot menjawab via muse-bridge |
| `providers.custom.base_url` | `http://localhost:20128/v1` | Gateway lewat 9router |
| `gateway.standalone` | `true` | Profil sekunder **wajib** standalone, kalau tidak gagal start |
| `gateway.trust_env` | `true` | Adapter Telegram menghormati `HTTP(S)_PROXY` dari env — tanpa ini koneksi Telegram timeout di lingkungan ber-proxy |
| `TELEGRAM_ALLOWED_USERS` | ID numerik | Hanya user terdaftar yang bisa memakai bot |

## Catatan operasi (pelajaran instalasi asal)

- **Jangan restart gateway saat proxy credential rotate.** `keep.sh`
  meng-update `hermes-gateway.env` diam-diam; gateway yang crash di-restart
  systemd sendiri dengan env terbaru. Restart manual/berkala memicu
  *restart-loop breaker* hermes dan memutus polling Telegram.
- **Restart gateway men-DROP semua pesan in-flight** — restart hanya saat idle.
- Alert kesehatan (`systemd/health-alert.sh`) memakai token/chat dari
  `.env` profil ini; tanpa `.env`, alert dilewatkan diam-diam.

## Verifikasi

```bash
systemctl is-active hermes-gateway
# kirim pesan ke bot Telegram → balasan datang sebagai Muse target
```
